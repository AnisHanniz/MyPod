﻿Installation du site : 
        
* Mettre les identifiants contenu dans public_html\config\database.php dans votre gestionnaire de base de données (nous avons opté pour phpMyAdmin) pour assurer le lien entre le site et la base de données.


* Puis importer le fichier bdd.sql se trouvant dans public_html\config\bdd.sql et l'exécuter pour remplir la base de données des informations nécessaires.


* Accéder à l’endroit du projet depuis votre url localhost, à la racine du projet vous serez sur la page de connexion, pour vous identifier.


* Avant toute authentification il important d’accéder à localhost/[racine_du_projet]/php/hash_password_existant.php ce lien permet de crypter les mots de passe contenus dans la base de données ce qui permet par la suite lors de la connexion de pouvoir s’authentifier avec le serveur qui va matcher votre saisie avec le mot de passe haché.


* Enfin vous pouvez retourner à localhost/[racine_du_projet]/ pour vous authentifier en tant que médecin ou admin.