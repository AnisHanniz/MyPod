/* DROP DATABASE id21995485_mypoddb; */

CREATE DATABASE IF NOT EXISTS id21995485_mypoddb;
USE id21995485_mypoddb;

-- Table pour stocker les informations des médecins
CREATE TABLE IF NOT EXISTS Medecins (
    MedecinID INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    NumeroTel VARCHAR(20),
    mail VARCHAR(255) UNIQUE,
    Cree TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table pour stocker les informations personnelles des patients
CREATE TABLE IF NOT EXISTS Patients (
    PatientID INT AUTO_INCREMENT PRIMARY KEY,
    MedecinID INT,
    Nom VARCHAR(50) NOT NULL,
    Prenom VARCHAR(50) NOT NULL,
    Naissance DATE,
    Age INT,
    Adresse VARCHAR(255),
    Telephone VARCHAR(20),
    mail VARCHAR(255) UNIQUE,
    Cree TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (MedecinID) REFERENCES Medecins(MedecinID) ON DELETE CASCADE
);

-- Table pour stocker le plan de traitement
CREATE TABLE IF NOT EXISTS PlansTraitement (
    PlanID INT AUTO_INCREMENT PRIMARY KEY,
    PatientID INT,
    MAJ TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    horaire_debut TIME,
    horaire_fin TIME,
    dose FLOAT,
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS HistoriqueInjections (
    HistoryID INT AUTO_INCREMENT PRIMARY KEY,
    PatientID INT,
    TempsInjection TIME,
    DateInjection DATE, 
    Dose FLOAT,
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE
);

-- Table pour stocker les informations des administrateurs
CREATE TABLE IF NOT EXISTS Admins (
    AdminID INT AUTO_INCREMENT PRIMARY KEY,
    mail VARCHAR(255) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS LoginPatient (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idpatient INT,
    motdepasse VARCHAR(255),
    mail VARCHAR(255),
    FOREIGN KEY (idpatient) REFERENCES Patients(PatientID) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS LoginMedecin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    MedecinID INT,
    motdepasse VARCHAR(255),
    mail VARCHAR(255),
    FOREIGN KEY (MedecinID) REFERENCES Medecins(MedecinID) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS ArchivePatient (
    ArchiveID INT AUTO_INCREMENT PRIMARY KEY,
    PatientID INT,
    MedecinID INT,
    Nom VARCHAR(50) NOT NULL,
    Prenom VARCHAR(50) NOT NULL,
    Naissance DATE,
    Age INT,
    Adresse VARCHAR(255),
    Telephone VARCHAR(20),
    mail VARCHAR(255) UNIQUE,
    Cree TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ArchiveMedecin (
    ArchiveID INT AUTO_INCREMENT PRIMARY KEY,
    MedecinID INT,
    Nom VARCHAR(50) NOT NULL,
    Prenom VARCHAR(50) NOT NULL,
    NumeroTel VARCHAR(20),
    mail VARCHAR(255) UNIQUE,
    motdepasse VARCHAR(100) NOT NULL,
    Cree TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (MedecinID) REFERENCES Medecins(MedecinID) ON DELETE CASCADE
);

-- Alimentation des tables
-- Insertion de données dans la table Medecins
INSERT INTO Medecins (nom, prenom, NumeroTel, mail)
VALUES
    ('Dr. Dupont', 'Jean', '555-123-4567', 'dr.dupont@example.com'),
    ('Dr. Martin', 'Sophie', '555-987-6543', 'dr.martin@example.com'),
    ('Dr. Andre', 'Emily','555-987-6544', 'dr.andre@example.com');
-- Insertion de données dans la table Patients
INSERT INTO Patients (MedecinID, Nom,Prenom, Naissance, Adresse, Telephone, mail)
VALUES
    (1, 'Hanniz','Anis', '1999-06-14', '456 Rue B', '0777959043', 'hanniz.n.anis@gmail.com'),
    (2, 'patient1','patient1', '1995-05-20', '123 Rue A', '0612345678', 'patient1@example.com'),
    (3, 'Pharell','Leila', '1995-05-20', '123 Rue A', '0612345678', 'leila.dupont@gmail.com');

-- Insertion de données dans la table PlansTraitement
INSERT INTO PlansTraitement (PatientID, horaire_debut, horaire_fin, dose)
VALUES
    (1,'00:00:00', '08:00:00', 0.4),
    (1,'08:00:00', '14:00:00', 0.7),
    (1,'14:00:00', '20:00:00', 0.6),
    (1,'20:00:00', '24:00:00', 0.5);



-- Insertion de données dans la table Admins
INSERT INTO Admins (mail, PasswordHash)
VALUES
    ('admin@example.com', 'hashadmin');

-- Insertion de données dans la table LoginPatient
INSERT INTO LoginPatient (idpatient, motdepasse, mail)
VALUES
    (1,'deesse','hanniz.n.anis@gmail.com'),
    (2, 'motdepasse1' ,'patient1@example.com'),
    (3, 'leila' ,'leila@gmail.com');
    
    -- Insertion de données dans la table LoginMEdecin
INSERT INTO LoginMedecin (MedecinID, motdepasse, mail)
VALUES
    (1,'motdepasse1','dr.dupont@example.com'),
    (2, 'motdepasse2' ,'dr.martin@example.com'),
    (3, 'motdepasse3' ,'dr.andre@example.com');
-- Mise à jour de l'âge des patients
UPDATE Patients
SET Age = TIMESTAMPDIFF(YEAR, Naissance, CURDATE());
