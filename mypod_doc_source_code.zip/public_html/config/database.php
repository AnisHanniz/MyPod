<?php
// config.php

// Définition de la durée de vie de la session en secondes (par exemple, 1 heure)
$session_lifetime = 3600; // 1 heure

// Configuration de la durée de vie de la session
session_set_cookie_params($session_lifetime);
session_start();

// Fonction pour obtenir la connexion à la base de données
function getDB() {
    $host = 'localhost';
    $username = 'id21995485_new_user';
    $password = 'Password_l3';
    $database = 'id21995485_mypoddb';
    $conn = new mysqli($host, $username, $password, $database);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}
?>
