<?php
session_start();
require "../../config/database.php";
//require "../session_token/token_check.php";
$conn = getDB();

if (isset($_POST['id']) ) {
    //&& isset($_POST['token'])
    $id = $_POST['id'];
    //$token = $_POST['token'];
    
    //if (checkAuthentication($token)) {
        // Récupérer l'heure et la date de la dernière mise à jour du schéma basal
        $timeQuery = "SELECT TIME(MAJ) AS heure, DATE(MAJ) AS date FROM PlansTraitement WHERE PatientID = '$id' ORDER BY maj DESC LIMIT 1";
        $execTimeQuery = mysqli_query($conn, $timeQuery);

        if ($execTimeQuery) {
            $result = mysqli_fetch_array($execTimeQuery);
            $heure = $result['heure'];
            $date = $result['date'];

            // Récupérer le dernier schéma basal
            $lastSchemaQuery = "SELECT horaire_debut, horaire_fin, dose FROM PlansTraitement WHERE PatientID = '$id' AND DATE_FORMAT(MAJ, '%H:%i:%s') = '$heure' AND DATE_FORMAT(MAJ, '%Y-%m-%d') = '$date'";
            $execLastSchemaQuery = mysqli_query($conn, $lastSchemaQuery);

            if ($execLastSchemaQuery) {
                $result = array();
                while ($row = mysqli_fetch_assoc($execLastSchemaQuery)) {
                    $result[] = $row;
                }
                echo json_encode($result);
            } else {
                // Gérer l'erreur si la requête échoue
                echo json_encode(array("error" => "Erreur lors de la récupération du dernier schéma basal"));
            }
        } else {
            // Gérer l'erreur si la requête échoue
            echo json_encode(array("error" => "Erreur lors de la récupération de l'heure et de la date"));
        }
    //} else {
        // Token invalide
    //    echo json_encode(array("error" => "Token invalide", "id" => $id, "token" => $token));
    //}
} else {
    // Données de requête manquantes
    echo json_encode(array("error" => "Données de requête manquantes"));
}

mysqli_close($conn);
?>
