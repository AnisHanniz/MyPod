<?php


// Fonction pour vérifier si l'utilisateur est connecté
function checkAuthentication($token) {
    // Vérifier si le token est présent dans la session
    session_start();
    if(isset($_SESSION[$token]) && $_SESSION[$token] === 'OK') {
        return true; // L'utilisateur est connecté
    } else {
        return false; // L'utilisateur n'est pas connecté
    }
}
?>