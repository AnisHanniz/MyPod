<?php
require "../../config/database.php";
$conn = getDB();

function login($conn, $mail, $password) {
    $stmt = $conn->prepare("SELECT idpatient, motdepasse FROM LoginPatient WHERE mail = ?");
    $stmt->bind_param("s", $mail);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['motdepasse'];

        // Vérifier si le mot de passe correspond au hash
        if (password_verify($password, $hashedPassword)) {
            // Générer un jeton
            $token = generateToken();

            // Stocker le token dans une session (ou une base de données)
            session_start();
            $_SESSION[$token] = "OK";

            // Retourner les informations sous forme de tableau associatif
            return array(
                'success' => true,
                'id' => $row['idpatient'],
                'message' => 'Authentification réussie',
                'token' => $token
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Mail ou mot de passe incorrect'
            );
        }
    } else {
        return array(
            'success' => false,
            'message' => 'Mail ou mot de passe incorrect'
        );
    }
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

// Vérifier si l'mail et le mot de passe ont été envoyés
if (isset($_POST['mail']) && isset($_POST['password'])) {
    $mail = $_POST['mail'];
    $password = $_POST['password'];

    $response = login($conn, $mail, $password);

    // Retourner la réponse au format JSON
    header('Content-Type: application/json');
    echo json_encode($response);
}

// Fermer la connexion à la base de données
$conn->close();
?>
