<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../../phpmailer/src/Exception.php';
require "../../phpmailer/src/PHPMailer.php";
require '../../phpmailer/src/SMTP.php';
require "../../config/database.php";
$conn = getDB();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

$mail->isSMTP();

$mail->Host = 'smtp.gmail.com';

$mail->SMTPAuth = true;

$mail->Username = 'mypodagdm@gmail.com';

$mail->Password = 'zdmo gmbx mqgr wvsq  ';

$mail->SMTPSecure = 'ssl';

$mail->Port = 465;



$mail->setFrom('mypodagdm@gmail.com');

$mail->isHTML(true);
$mail->Subject = 'Réinitialisation du mot de passe';

function genererCodeAleatoire($longueur = 8)
{
    $caracteres = '0123456789';
    $lettres = 'abcdefghijklmnopqrstuvwxyz';
    $symboles = '@/.;()';
    $code = '';

    $longueur_symboles = ceil($longueur / 4);

    for ($i = 0; $i < $longueur_symboles; $i++) {
        $code .= $symboles[rand(0, strlen($symboles) - 1)];
    }

    $longueur_restante = $longueur - $longueur_symboles;
    for ($i = 0; $i < $longueur_restante; $i++) {
        if ($i % 2 == 0) {
            $code .= $caracteres[rand(0, strlen($caracteres) - 1)];
        } else {
            $code .= $lettres[rand(0, strlen($lettres) - 1)];
        }
    }

    $code = str_shuffle($code);
    return $code;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mail = mysqli_real_escape_string($conn, htmlspecialchars($_POST['mail']));

    $requetemailExiste = "SELECT * FROM Patients WHERE mail = '$mail'";
    $resultatmailExiste = mysqli_query($conn, $requetemailExiste);

    if (!$resultatmailExiste) {
        echo json_encode(array("message" => "Database Error: " . mysqli_error($conn)));
        exit();
    }

    $rowmailExiste = mysqli_fetch_assoc($resultatmailExiste);

    if ($rowmailExiste) {
        $code = genererCodeAleatoire();

        // Hasher le nouveau mot de passe
        $hashedPassword = password_hash($code, PASSWORD_DEFAULT);

        $requeteEnregistrementCode = "UPDATE LoginPatient SET motdepasse = '$hashedPassword' WHERE mail = '$mail'";
        $resultatEnregistrementCode = mysqli_query($conn, $requeteEnregistrementCode);

        if (!$resultatEnregistrementCode) {
            echo json_encode(array("message" => "Database Error: " . mysqli_error($conn)));
            exit();
        }

        $sujet = "Réinitialisation de mot de passe";
        $message = "Votre code de réinitialisation de mot de passe est : $code . Pour le modifier contacter un administrateur.";

        $mail->addAddress($mail);
        $mail->Body = $message;

        try {
            $mail->send();
            echo json_encode(array("message" => "Un code de réinitialisation a été envoyé à l'adresse e-mail: $mail"));
        } catch (Exception $e) {
            echo json_encode(array("message" => "Erreur lors de l'envoi de l'mail: {$mail->ErrorInfo}"));
        }
    } else {
        echo json_encode(array("message" => "L'adresse e-mail n'est pas enregistrée dans notre système."));
    }
}
