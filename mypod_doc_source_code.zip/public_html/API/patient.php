<?php
session_start();

require "../config/database.php";
$conn = getDB();

if (isset($_GET['mail'])) {
    $mail = $_GET['mail'];
    $requeteAdmin = "SELECT * FROM Patients WHERE mail = '$mail'";
    $exec_requeteAdmin = mysqli_query($conn, $requeteAdmin);

    if ($exec_requeteAdmin) {
        echo(json_encode(mysqli_fetch_array($exec_requeteAdmin)));
    } else {
        echo json_encode(['error' => 'Erreur de communication avec la base de données']);
    }
    mysqli_close($conn);
} else {
    echo json_encode(['error' => 'Aucun mail fourni']);
}
?>