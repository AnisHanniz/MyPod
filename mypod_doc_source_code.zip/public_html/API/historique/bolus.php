<?php
require "../../config/database.php";
$conn = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Changement de GET à POST
    // Récupération des données POST
    $patientID = isset($_POST['PatientID']) ? $_POST['PatientID'] : null;
    $tempsInjection = isset($_POST['TempsInjection']) ? $_POST['TempsInjection'] : null;
    $dateInjection = isset($_POST['DateInjection']) ? $_POST['DateInjection'] : null;
    $dose = isset($_POST['Dose']) ? $_POST['Dose'] : null;

    // Vérification des doublons
    $query = "SELECT COUNT(*) AS count FROM HistoriqueInjections WHERE PatientID = :patientID AND TempsInjection = :tempsInjection AND DateInjection = :dateInjection AND Dose = :dose";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':patientID', $patientID);
    $stmt->bindParam(':tempsInjection', $tempsInjection);
    $stmt->bindParam(':dateInjection', $dateInjection);
    $stmt->bindParam(':dose', $dose);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['count'] > 0) {
        // Doublon trouvé, renvoie une réponse appropriée
        http_response_code(409); // Conflict
        echo json_encode(array("message" => "Duplicate entry detected"));
    } else {
        // Pas de doublon, insérer dans la base de données
        $query = "INSERT INTO HistoriqueInjections (PatientID, TempsInjection, DateInjection, Dose) VALUES (:patientID, :tempsInjection, :dateInjection, :dose)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':patientID', $patientID);
        $stmt->bindParam(':tempsInjection', $tempsInjection);
        $stmt->bindParam(':dateInjection', $dateInjection);
        $stmt->bindParam(':dose', $dose);

        if ($stmt->execute()) {
            http_response_code(201); // Created
            echo json_encode(array("message" => "Injection recorded successfully"));
        } else {
            http_response_code(500); // Server error
            echo json_encode(array("message" => "Failed to record injection"));
        }
    }
} else {
    // Méthode HTTP non autorisée
    http_response_code(405); // Method Not Allowed
    echo json_encode(array("message" => "Method not allowed"));
}
?>
