<?php
// Active l'affichage des erreurs PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Inclut le fichier de configuration de la base de données
require "../config/database.php";

// Obtient une connexion à la base de données
$conn = getDB();

// Vérifie si l'identifiant du patient est présent dans la requête GET
if (isset($_GET['id'])) {
    // Échappe les données provenant de la requête GET pour éviter les injections SQL
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Requête pour obtenir l'heure et la date de la dernière mise à jour pour ce patient
    $timeQuery = "SELECT TIME(MAJ) AS heure, DATE(MAJ) AS date FROM PlansTraitement WHERE PatientID = '$id' ORDER BY maj DESC LIMIT 1";
    $exec_time = mysqli_query($conn, $timeQuery);

   // Vérifie si la requête s'est exécutée avec succès et s'il y a des résultats
if ($exec_time && mysqli_num_rows($exec_time) > 0) {
    // Récupère l'heure et la date de la dernière mise à jour
    $result = mysqli_fetch_array($exec_time);
    $heure = $result['heure'];
    $date = $result['date'];
} else {
    // Gère l'erreur si la requête échoue ou s'il n'y a pas de résultats
    echo json_encode(array("error" => "Aucune donnée trouvée"));
    exit(); // Arrête l'exécution du script
}


    // Requête pour obtenir les données du dernier schéma de traitement pour ce patient à l'heure et à la date spécifiées
    $lastSchemaQuery = "SELECT horaire_debut, horaire_fin, dose FROM PlansTraitement WHERE PatientID = '$id' AND DATE_FORMAT(MAJ, '%H:%i:%s') = '$heure' AND DATE_FORMAT(MAJ, '%Y-%m-%d') = '$date'";
    $exec_last_requete = mysqli_query($conn, $lastSchemaQuery);

    // Vérifie si la requête s'est exécutée avec succès
    if ($exec_last_requete) {
        // Initialise un tableau pour stocker les résultats
        $result = array();
        
        // Parcourt les résultats et les ajoute au tableau
        while ($row = mysqli_fetch_assoc($exec_last_requete)) {
            $result[] = $row;
        }

        // Renvoie les résultats au format JSON
        echo json_encode($result);
    } else {
        // Gère l'erreur si la requête échoue
        echo json_encode(array("error" => mysqli_error($conn)));
    }
} else {
    // Gère l'erreur si l'identifiant du patient est manquant dans la requête GET
    echo json_encode(array("error" => "Identifiant du patient manquant"));
}

// Ferme la connexion à la base de données
mysqli_close($conn);
?>
