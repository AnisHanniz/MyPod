<?php

session_start();

require "../config/database.php";

$conn = getDB();



if (isset($_GET['patientid'])) {

    $patientid = $_GET['patientid'];

    foreach ($_POST['traitements'] as $traitement) {

        $debut = $traitement['debut'];

        $fin = $traitement['fin'];

        $dose = $traitement['dose'];



        $nv_plage_horaire = "INSERT INTO PlansTraitement (PatientID, horaire_debut, horaire_fin, dose) VALUES ( $patientid, '$debut', '$fin', $dose)";

        $exec_plage_horaire = mysqli_query($conn, $nv_plage_horaire);

        if (!$exec_plage_horaire) {

            echo "Erreur lors de l'insertion de la plage horaire : " . mysqli_error($conn);

        }

    }

} else {

    echo "Erreur lors de l'insertion du plan de traitement : " . mysqli_error($conn);

}

header("Location: bdd.php?patientid=$patientid");

mysqli_close($conn);

?>

