<?php
session_start();
require "../config/database.php";
$conn = getDB();

// On vérifie qu'on a reçu l'email et le mot de passe du formulaire
if (isset($_POST['email']) && isset($_POST['password'])) {

    // On applique les fonctions mysqli_real_escape_string et htmlspecialchars
    // pour éliminer toute attaque de type injection SQL et XSS
    $email = mysqli_real_escape_string($conn, htmlspecialchars($_POST['email']));
    $password = mysqli_real_escape_string($conn, htmlspecialchars($_POST['password']));

    if ($email !== "" && $password !== "") {
        // Vérification si c'est un médecin
        $requeteMedecin = "SELECT MedecinID, motdepasse FROM LoginMedecin WHERE 
            mail = '$email'";
        $exec_requeteMedecin = mysqli_query($conn, $requeteMedecin);
        $reponseMedecin = mysqli_fetch_array($exec_requeteMedecin);
        $countMedecin = mysqli_num_rows($exec_requeteMedecin);

        // Vérification si c'est un administrateur
        $requeteAdmin = "SELECT AdminID, PasswordHash FROM Admins WHERE 
            mail = '$email'";
        $exec_requeteAdmin = mysqli_query($conn, $requeteAdmin);
        $reponseAdmin = mysqli_fetch_array($exec_requeteAdmin);
        $countAdmin = mysqli_num_rows($exec_requeteAdmin);

        if ($countMedecin > 0 || $countAdmin > 0) {
            if ($countMedecin > 0) { // C'est un médecin
                // Vérification du mot de passe haché
                if (password_verify($password, $reponseMedecin['motdepasse'])) {
                    $_SESSION['adressemail'] = $email;
                    $_SESSION['nom'] = $reponseMedecin['nom'];
                    $_SESSION['id'] = $reponseMedecin['MedecinID'];
                } else {
                    header('Location: ../index.php?erreur=1'); // Mot de passe incorrect
                    exit(); // Terminer le script après la redirection
                }
            } elseif ($countAdmin > 0) { // C'est un administrateur
                // Vérification du mot de passe haché
                $_SESSION['adressemail'] = $email; // TODO à dégager

                /* if (password_verify($password, $reponseAdmin['PasswordHash'])) {
                    $_SESSION['adressemail'] = $email;
                } else {
                    header('Location: ../index.php?erreur=1'); // Mot de passe incorrect
                    exit(); // Terminer le script après la redirection
                } */
            }
            header('Location: bdd.php'); // Redirige vers la page bdd.php après la connexion
            exit(); // Terminer le script après la redirection
        } else {
            header('Location: ../index.php?erreur=1'); // Email incorrect
            exit(); // Terminer le script après la redirection
        }
    } else {
        header('Location: ../index.php?erreur=2'); // Email ou mot de passe vide
        exit(); // Terminer le script après la redirection
    }
} else {
    // Sinon, on redirige vers l'accueil
    header('Location: ../index.php');
    exit(); // Terminer le script après la redirection
}

mysqli_close($conn); // Fermer la connexion
