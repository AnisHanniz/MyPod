<?php

error_reporting(E_ALL);

ini_set('display_errors', 1);


require "../config/database.php";

require '../phpmailer/src/Exception.php';

require "../phpmailer/src/PHPMailer.php";

require '../phpmailer/src/SMTP.php';

$conn = getDB();



use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\Exception;



$mail = new PHPMailer(true);

$mail->isSMTP();

$mail->Host = 'smtp.gmail.com';

$mail->SMTPAuth = true;

$mail->Username = 'mypodagdm@gmail.com';

$mail->Password = 'zdmo gmbx mqgr wvsq  ';

$mail->SMTPSecure = 'ssl';

$mail->Port = 465;



$mail->setFrom('mypodagdm@gmail.com');



$mail->isHTML(true);

$mail->Subject = 'Recuperation mot de passe';



// Fonction pour générer un code aléatoire

function genererCodeAleatoire($longueur = 8)
{

    $caracteres = '0123456789';

    $lettres = 'abcdefghijklmnopqrstuvwxyz';

    $symboles = '@/.;()';

    $code = '';



    // Calculer le nombre de caractères à choisir pour les symboles

    $longueur_symboles = ceil($longueur / 4);



    // Ajouter les symboles au code

    for ($i = 0; $i < $longueur_symboles; $i++) {

        $code .= $symboles[rand(0, strlen($symboles) - 1)];
    }



    // Remplir le reste de la longueur avec des caractères et des lettres alternés

    $longueur_restante = $longueur - $longueur_symboles;

    for ($i = 0; $i < $longueur_restante; $i++) {

        if ($i % 2 == 0) {

            $code .= $caracteres[rand(0, strlen($caracteres) - 1)];
        } else {

            $code .= $lettres[rand(0, strlen($lettres) - 1)];
        }
    }



    // Mélanger le code pour rendre les symboles répartis de manière aléatoire

    $code = str_shuffle($code);

    return $code;
}





if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = mysqli_real_escape_string($conn, htmlspecialchars($_POST['email']));



    // Vérifier si l'email existe dans la base de données

    $requeteEmailExiste = "SELECT * FROM Medecins WHERE mail = '$email'";

    $resultatEmailExiste = mysqli_query($conn, $requeteEmailExiste);

    $rowEmailExiste = mysqli_fetch_assoc($resultatEmailExiste);



    if ($rowEmailExiste) {

        // Générer un code aléatoire

        $code = genererCodeAleatoire();

        // Enregistrement du code dans la base de données

        $requeteEnregistrementCode = "UPDATE LoginMedecin SET motdepasse = '$code' WHERE mail = '$email'";

        mysqli_query($conn, $requeteEnregistrementCode);





        $sujet = "Réinitialisation de mot de passe";

        $message =

            '

        <!DOCTYPE html>

        <html lang="fr">

        <head>

            <meta charset="UTF-8">

            <title>Réinitialisation de mot de passe</title>

        </head>

        <body>

            <p> Votre code de réinitialisation de mot de passe est :<strong>' . $code . '</strong></p>
            <p>Pour le modifier, contactez un administrateur.</p>

            <a href="http://mypodev.000webhostapp.com/index.php">Retour au site</a>

        </body>

        </html>

        

            ';

        $headers = "From: test@dine.local";

        $mail->addAddress($email);

        $mail->Body = $message;

        $mail->send();



        echo "Un code de réinitialisation a été envoyé à l'adresse e-mail: " . $email;
    } else {

        echo "L'adresse e-mail n'est pas enregistrée dans notre système.";
    }
}

?>

<!DOCTYPE html>



<html lang="fr">



<head>

    <title>Plateforme Médecins - MyPod</title>

    <meta charset="utf-8" />

    <link rel="stylesheet" href="../web/forget.css" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</head>



<body>

    <div class="container">

        <div class="login-form">

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">

                <h1>Réinitialisation de mot de passe</h1>

                <div class="form-group">

                    <label for="email">Adresse E-mail :</label>

                    <input type="email" id="email" name="email" required>

                </div>

                <button type="submit">Envoyer le code de réinitialisation</button>

                <div class="form-footer">

                    <a href="../index.php">Retour à la page de connexion</a>

                </div>

            </form>

        </div>

    </div>

</body>



</html>