<?php

require "../config/database.php";

$conn = getDB();

try {

    // Vérifier la connexion

    if (!$conn) {

        die("La connexion a échoué : " . mysqli_connect_error());
    }
    // Récupérer les données du formulaire

    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $numeroTel = $_POST["numero_tel"];
    $email = $_POST["email"];
    $adresse = $_POST["adresse"];
    $dateNaissance = $_POST["date_naissance"];
    $idMedecin = isset($_GET['id']) ? $_GET['id'] : $_POST['medecin'];



    // Vérifier si l'email est déjà utilisé

    $requete = "SELECT * FROM Patients WHERE mail = '$email'";

    $res = mysqli_query($conn, $requete);

    $resultat = mysqli_fetch_array($res);



    if ($resultat) {
        header('Location: ./bdd.php');
        exit;
    } else {

        // Insérer le nouveau profil dans la table Medecins

        $requete = "INSERT INTO Patients (Nom, Prenom, Adresse, Telephone, mail, Naissance, MedecinID ) 
                    VALUES ('$nom', '$prenom', '$adresse', '$numeroTel', '$email', '$dateNaissance', '$idMedecin')";



        if (!mysqli_query($conn, $requete)) {
            throw new Exception("Erreur lors de la mise à jour des données du patient : " . mysqli_error($conn));
        }
    }

    $nouveau_patient_id = mysqli_insert_id($conn);
    $requete = "UPDATE Patients 

    SET Age = TIMESTAMPDIFF(YEAR, Naissance, CURDATE()) 

    WHERE PatientID = '$nouveau_patient_id';
    ";

    if (!mysqli_query($conn, $requete)) {

        throw new Exception("Erreur lors de la mise à jour des données du patient : " . mysqli_error($conn));
    }
    $requete = "INSERT INTO LoginPatient (idpatient,mail )  VALUES ('$nouveau_patient_id','$email')";

    if (!mysqli_query($conn, $requete)) {

        throw new Exception("Erreur lors de la mise à jour des données du patient : " . mysqli_error($conn));
    }
} catch (Exception $e) {

    die('Erreur : ' . $e->getMessage());
}


require '../phpmailer/src/Exception.php';

require '../phpmailer/src/PHPMailer.php';

require '../phpmailer/src/SMTP.php';





use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

$mail->isSMTP();

$mail->Host = 'smtp.gmail.com';

$mail->SMTPAuth = true;

$mail->Username = 'mypodagdm@gmail.com';

$mail->Password = 'zdmo gmbx mqgr wvsq  ';

$mail->SMTPSecure = 'ssl';

$mail->Port = 465;



$mail->setFrom('mypodagdm@gmail.com');



$mail->isHTML(true);

$mail->Subject = 'Premiere connexion';

// Fonction pour générer un code aléatoire

function genererCodeAleatoire($longueur = 8)
{

    $caracteres = '0123456789';

    $lettres = 'abcdefghijklmnopqrstuvwxyz';

    $symboles = '@/.;()';

    $code = '';



    // Calculer le nombre de caractères à choisir pour les symboles

    $longueur_symboles = ceil($longueur / 4);



    // Ajouter les symboles au code

    for ($i = 0; $i < $longueur_symboles; $i++) {

        $code .= $symboles[rand(0, strlen($symboles) - 1)];
    }



    // Remplir le reste de la longueur avec des caractères et des lettres alternés

    $longueur_restante = $longueur - $longueur_symboles;

    for ($i = 0; $i < $longueur_restante; $i++) {

        if ($i % 2 == 0) {

            $code .= $caracteres[rand(0, strlen($caracteres) - 1)];
        } else {

            $code .= $lettres[rand(0, strlen($lettres) - 1)];
        }
    }



    // Mélanger le code pour rendre les symboles répartis de manière aléatoire

    $code = str_shuffle($code);

    return $code;
}
if (!$resultat) {
    // Générer un code aléatoire
    $code = genererCodeAleatoire();

    $password = mysqli_real_escape_string($conn, htmlspecialchars($code));

    // Enregistrement du code dans la base de données
    $requeteEnregistrementCode = "UPDATE LoginPatient SET motdepasse = '$password' WHERE mail = '$email'";

    if (!mysqli_query($conn, $requeteEnregistrementCode)) {
        throw new Exception("Erreur lors de la mise à jour du mot de passe du patient : " . mysqli_error($conn));
    }

    $sujet = "Première connexion ";
    $message = '
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <title>Premier mot de passe</title>
        </head>
        <body>
            <p> Votre mot de passe pour votre première connexion sur notre application est :<strong>' . $code . '</strong></p>
            <a href="http://mypodev.000webhostapp.com/index.php">Retour au site</a>
        </body>
        </html>';

    $headers = "From: test@dine.local";
    $mail->addAddress($email);
    $mail->Body = $message;

    if (!$mail->send()) {
        throw new Exception("L'email n'a pas pu être envoyé : " . $mail->ErrorInfo);
    }
    header('Location: bdd.php');
}

mysqli_close($conn);
exit;
