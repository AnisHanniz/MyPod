<?php
session_start();
require "../config/database.php";
$conn = getDB();
try {

    // Vérifier la connexion
    if (!$conn) {
        throw new Exception("La connexion a échoué : " . mysqli_connect_error());
    }
    $patientID = $_GET['id'];
    
    
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $numeroTel = $_POST["numero_tel"];
    $email = $_POST["email"];
    $adresse = $_POST["adresse"];
    $dateNaissance = $_POST["date_naissance"];

   
    $requete = "UPDATE Patients 
            SET Nom = '$nom', 
                Prenom = '$prenom', 
                Adresse = '$adresse', 
                Telephone = '$numeroTel', 
                mail = '$email', 
                Naissance = '$dateNaissance' 
            WHERE PatientID = '$patientID'";

    if (!mysqli_query($conn, $requete)) {
        throw new Exception("Erreur lors de la mise à jour des données du patient : " . mysqli_error($conn));
    }
   
    $requete = "UPDATE Patients 
    SET Age = TIMESTAMPDIFF(YEAR, Naissance, CURDATE()) 
    WHERE PatientID = '$patientID';
    ";

if (!mysqli_query($conn, $requete)) {
throw new Exception("Erreur lors de la mise à jour des données du patient : " . mysqli_error($conn));
}
    // Fermer la connexion
    mysqli_close($conn);

    // Redirection vers bdd.php si tout s'est bien passé
    header('Location: bdd.php');
    exit(); // Assurez-vous de terminer le script après la redirection
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}
?>
