<?php
require "../config/database.php";
$conn = getDB();
try {
    // Vérifier la connexion
    if (!$conn) {
        die("La connexion a échoué : " . mysqli_connect_error());
    }

    // Récupérer les données du formulaire
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $specialite = $_POST["specialite"];
    $numeroTel = $_POST["telephone"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Vérifier si l'email est déjà utilisé
    $requete = "SELECT * FROM Medecins WHERE mail = '$email'";
    $res = mysqli_query($conn, $requete);
    $resultat = mysqli_fetch_array($res);

    if ($resultat) {
        echo "L'email est déjà utilisé.";
        header('Location: pagedinscription.php');
        exit; // Arrêter l'exécution du script après la redirection
    } else {
        // Insérer le nouveau profil dans la table Medecins
        $requete_insert = "INSERT INTO Medecins (nom, prenom, NumeroTel, mail) VALUES ('$nom', '$prenom', '$numeroTel', '$email')";
        mysqli_query($conn, $requete_insert);

        // Récupérer l'ID du médecin inséré
        $requete_id = "SELECT MedecinID FROM Medecins WHERE mail = '$email'";
        $resultat_id = mysqli_query($conn, $requete_id);

        if ($resultat_id && mysqli_num_rows($resultat_id) > 0) {
            $row = mysqli_fetch_assoc($resultat_id);
            $medecin_id = $row['MedecinID'];

            // Hasher le mot de passe
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // Insérer les informations de connexion dans la table LoginMedecin
            $requete_login = "INSERT INTO LoginMedecin (MedecinID, motdepasse, mail) VALUES ('$medecin_id', '$hash', '$email')";
            mysqli_query($conn, $requete_login);
        } else {
            echo "Erreur lors de la récupération de l'ID du médecin.";
        }
       header('location: ../index.php');
    }

    // Fermer la connexion
    mysqli_close($conn);
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}
?>
