<?php
session_start();
include("../config/database.php");
$conn = getDB();
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../web/style-accueil.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Accueil - Médecin</title>

</head>

<body>
    <?php
    $isSelected = false;

    $date_format_Ymd = date('Y-m-d');
    ?>
    <nav id='nav'>
        <ul>
            <?php
            if ($conn->connect_error) {
                die("Erreur de connexion à la base de données: " . $conn->connect_error);
            }

            $mail = $_SESSION['adressemail'];
            $sql = "SELECT * FROM Medecins WHERE mail = '$mail'";
            $result_identity = $conn->query($sql);
            if ($result_identity->num_rows > 0) {
                $nom = $_SESSION['nom'];
                $doctor_co = true;
                $admin_co = false;
                $id = $_SESSION['id'];
            ?>
                <img src="../media/mypodinternet.png" class="img">
            <?php
                echo "<div class='name'>$nom</div>";
            } else {
                $admin_co = true;
                $doctor_co = false;
                echo "<li>Admin</li>";
            }
            ?>
            <br><br>
            <li><a href="bdd.php"><img class="icon" src="../media/house.svg" width="50" height="40" title="Retour accueil"></a></li>
            <?php
            if (isset($_GET['patientid'])) {
            ?>
                <li><a href="#" onclick="toggleBlur('popup_delete')"><img src="../media/trash.svg" alt="Image 1" width="50" height="40" title="Supprimer le patient"></a></li>
                <li><a href="#"><img class="icon" src="../media/pencil-square.svg" alt="Image 2" width="50" height="40" title="Modifier le patient" onclick="toggleBlur('popup_inf_patient')"></a></li>
            <?php
            }
            ?>
            <?php
            if (!isset($_GET['patientid'])) {
            ?>

                <li><a href="#" onclick="toggleBlur('popup_ajout_patient')"><img class="icon" src="../media/person-add.svg" width="50" height="40" title="Ajouter un nouveau patient"></a></li>
            <?php
            }
            ?>
            <li><a href="deconnection.php"><img class="icon" src="../media/door-open-fill.svg" width="40" height="50" title="Déconnexion"></a></li>
        </ul>
    </nav>

    <div id='blur' class='blur'></div>
    <div id='popup_ajout_patient' class='popup'>
        <div class='popup-content' style="justify-items: center;">
            <?php
            if ($admin_co) {
            ?>
                <button id="btnPatient" value="patient" onclick="updateIsSelected('patient')" class="btn_fermer" value="patient">Patient</button>
                <button id="btnMedecin" value="medecin" onclick="updateIsSelected('medecin')" class="btn_fermer" value="medecin">Médecin</button>
                <h2 id="title_add"></h2>
            <?php
            }
            ?>
            <?php
            if ($doctor_co) {
            ?>
                <form action="traitement_formulaire.php?id=<?php echo $_SESSION['id']; ?>" method="POST">
                <?php
            } else {
                ?>
                    <form id="formTraitement" method="POST">
                        <div id="formAdd">
                    <?php
                }
                   
                        if ($doctor_co) {
                    ?>
                            <label for="nom">Nom:</label>
                            <input type="text" id="nom" name="nom" placeholder="Nom" required><br><br>
                            <label for="prenom">Prénom:</label>
                            <input type="text" id="prenom" name="prenom" placeholder="Prénom" required><br><br>
                            <label for="date_naissance">Date de naissance:</label>
                            <input type="date" id="date_naissance" name="date_naissance" min="1924-01-01" max="<?php echo $date_format_Ymd; ?>" required><br><br>
                            <label for="email">Adresse E-mail:</label>
                            <input type="email" id="email" name="email" placeholder="Adresse E-mail" required><br><br>
                            <label for="telephone">Numéro de téléphone:</label>
                            <input type="text" id="telephone" name="telephone" placeholder="Numéro de téléphone" pattern="[0-9]{10}" required>
                        <?php }
                        ?>
                    </div>
                    <?php if ($admin_co) { ?>
                        <div id="patientAdd">
                            <?php
                            $tables = array("Medecins");
                            foreach ($tables as $table) {
                                $sql = "SELECT MedecinID,Nom,Prenom FROM $table";
                                $result = $conn->query($sql);
                            }
                            ?>


                            <label for="choix">Sélectionnez un médecin :</label>
                            <select id="idMedecin" name="medecin">
                                <?php
                                $sql = "SELECT MedecinID,Nom,Prenom FROM $table";
                                $exec_requeteMedecin = mysqli_query($conn, $sql);
                                while ($row = mysqli_fetch_array($exec_requeteMedecin)) {
                                ?>
                                    <option value="<?php echo $row['MedecinID']; ?>"><?php echo $row['Nom'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                        <br>
                    <?php } ?>
                    <button type="submit">Ajouter</button>
                    <button type="button" onclick="closePopup('popup_ajout_patient')" class="btn_fermer">Fermer</button>
                    <br>
                    </form>
                    <br>
        </div>
    </div>



    <div id="popup_traitement" class="popup">
        <div class="popup-content">
            <h2>Dosage par tranche horaire</h2>
            <form action="nouveau_traitement.php?patientid=<?php echo ($_GET['patientid']) ?>" method="POST">
                <div id="tout_traitement" style="margin-bottom: 20px;">
                </div>
                <br>
                <div>
                    <button type="button" onclick="plageHoraire()" id="ajouter_plage" class="button" style="background-color:  #4fb15c;">Ajouter une plage horaire</button>
                </div><br>
                <button type="submit">Soumettre le traitement</button>
                <button type="button" onclick="fermerPopupEtSupprimerTraitements()" class="btn_fermer">Fermer</button>

            </form>
        </div>
    </div>
    <?php
    $sql = "SELECT * FROM Medecins WHERE mail = '$mail'";
    $result_identity = $conn->query($sql);
    // Vérifiez s'il y a des résultats
    if ($result_identity->num_rows > 0) {
        // Récupérez les informations du médecin
        $medecin = $result_identity->fetch_assoc();
    ?>
        <div id='popup_mesinfo_blur' class='blur'></div>
        <div id='popup_mesinfo' class='popup'>
            <div class='popup-content' style="text-align: center;">
                <h2>Mes informations</h2>
                <label>Nom :</label>
                <div id="nom"><?php echo $medecin['nom']; ?></div>
                <br><br>
                <label>Prénom :</label>
                <div id="prenom"><?php echo $medecin['prenom']; ?></div>
                <br><br>
                <label>Adresse E-mail :</label>
                <div id="email"><?php echo $medecin['mail']; ?></div>
                <br><br>
                <label>Numéro de téléphone :</label>
                <div id="numero_tel"><?php echo $medecin['NumeroTel']; ?></div>
                <br><br>
                <button type="button" onclick="closePopup('popup_mesinfo')" class="btn_fermer">Fermer</button>
                </form>
            </div>
        </div>
        <div id='popup_inf_blur' class='blur'></div>
        <div id='popup_inf_patient' class='popup'>
            <div class='popup-content' style="text-align: center;">
                <h2>Infos Patient</h2>
                <form action="modif_patient.php?id=<?php echo $_GET['patientid']; ?>" method="POST">
                    <label for="nom">Nom:</label>
                    <input type="text" id="nom" name="nom" placeholder="Nom" required><br><br>
                    <label for="prenom">Prénom:</label>
                    <input type="text" id="prenom" name="prenom" placeholder="Prénom" required><br><br>
                    <label for="date_naissance">Date de naissance:</label>
                    <input type="date" id="date_naissance" name="date_naissance" min="1924-01-01" max="<?php echo $date_format_Ymd; ?>" required><br><br>
                    <label>Adresse E-mail</label>
                    <input type="email" name="email" required>
                    <label for="adresse">Adresse:</label>
                    <input type="text" id="adresse" name="adresse" placeholder="Adresse"><br><br>
                    <label for="numero_tel">Numéro de téléphone:</label>
                    <input type="text" id="numero_tel" name="numero_tel" placeholder="Numéro de téléphone" pattern="[0-9]{10}" required><br><br>
                    <br><br>
                    <button type="submit">Ajouter</button>
                    <button type="button" onclick="closePopup('popup_inf_patient')" class="btn_fermer">Fermer</button>
                </form>
            </div>
        </div>
    <?php
    }
    ?>
    <div id='popup_joindremp_blur' class='blur'></div>
    <div id='popup_joindremp' class='popup'>
        <div class='popup-content' style="text-align: center;">
            <h2>Joindre MyPod</h2>
            <form action="traitement_formulaire.php?id=<?php echo $_SESSION['id']; ?>" method="POST">
                <label for="message">Message (max. 500 caractères)</label>
                <textarea id="message" name="message" rows="4" maxlength="500" required style="max-width: 100%;"></textarea><br><br>
                <button type="submit">Soumettre</button>
                <button type="button" onclick="closePopup('popup_joindremp')" class="btn_fermer">Fermer</button>
            </form>
        </div>
    </div>
    <?php
    if (isset($_GET['patientid'])) {
        $patientid = $_GET['patientid'];
    }

    ?>
    <div id='popup_delete_blur' class='blur'></div>
    <div id='popup_delete' class='popup'>
        <div class='popup-content' style="text-align: center;">
            <form action="delete_patient.php?id=<?php echo $patientid; ?>" method="POST">
                <input type="hidden" name="patientid" value="<?php echo htmlspecialchars($_GET['patientid']); ?>">

                <h2>Voulez-vous vraiment supprimer ce patient ?</h2>
                <button type="submit">Confirmer</button>
                <button type="button" onclick="closePopup('popup_delete')" class="btn_fermer">Fermer</button>
            </form>
        </div>
    </div>
    <div id='popup_delete_blur_all' class='blur2'></div>
    <div id='popup_delete_all' class='popup'>
        <div class='popup-content' style="text-align: center;">
            <form>
                <h2 id="delete_popup_title">Voulez-vous vraiment supprimer ce patient ?</h2>
                <h2 id="delete_popup_title_desc"></h2>
                <button type="button" onclick="confirmAllDelete()">Confirmer</button>
                <button type="submit" onclick="closePopup('popup_delete_all')">Annuler</button>
            </form>
        </div>
    </div>
    <?php
    if (empty($_GET)) {
        if ($doctor_co) {
    ?>
            <h1 style="color: #8f1afd;">Tableau de Bord</h1>
            <div class="dashboard">
                <?php
                // Requête SQL pour compter le nombre de patients associés à ce médecin
                $count_query = "SELECT COUNT(*) AS patient_count FROM Patients WHERE MedecinID = '$id'";
                $count_result = $conn->query($count_query);

                // Requête SQL pour récupérer la date de création du dernier patient du médecin
                $creation_query = "SELECT Cree FROM Patients WHERE MedecinID = '$id' ORDER BY Cree DESC LIMIT 1";
                $creation_result = $conn->query($creation_query);

                // Vérifiez si les requêtes ont réussi
                if ($count_result && $creation_result) {
                    // Récupérez le nombre de patients
                    $row = $count_result->fetch_assoc();
                    $patient_count = $row['patient_count'];

                    // Récupérez la date de création du dernier patient du médecin
                    $row_creation = $creation_result->fetch_assoc();
                    if ($patient_count > 0) {
                        $creation_date = $row_creation['Cree'];
                    }
                    // Affichez les statistiques dans la section "Statistiques"
                    echo "<div class='widget'>";
                    echo "<h2>Statistiques</h2>";
                    echo "<p>Nombre de patients : $patient_count</p>";
                    if ($patient_count > 0) {
                        echo "<p>Dernier patient ajouté : $creation_date</p>";
                    }
                    echo "</div>";
                } else {
                    echo "Erreur lors de la récupération des statistiques.";
                }
                ?>
                <div class="widget">
                    <button class="btn_mes_info" onclick="toggleBlur('popup_mesinfo')">
                        <h2>Mes Informations</h2>
                    </button>
                </div>
                <div class="widget">
                    <button class="btn_mes_info" onclick="toggleBlur('popup_joindremp')">
                        <h2>Joindre MyPod</h2>
                    </button>
                </div>
            </div>
            <?php
        }
        if ($doctor_co) {
            $list_patient = "SELECT * FROM Patients WHERE MedecinID = '" . $id . "'";
            $resultat = $conn->query($list_patient);

            if ($resultat->num_rows > 0) {
                echo '<br><h2 style="text-align: center;">Liste des patients</h2>';
                echo '<table id="tableau">';
                echo '<tr>';

                // Affichage des entêtes de colonnes
                while ($fieldinfo = $resultat->fetch_field()) {
                    // Exclure les champs PatientID et MedecinID
                    if ($fieldinfo->name != 'PatientID' && $fieldinfo->name != 'MedecinID') {
                        echo '<th>' . $fieldinfo->name . '</th>';
                    }
                }
                echo '</tr>';

                // Affichage des lignes de données
                while ($row = $resultat->fetch_assoc()) {
                    echo '<tr>';
                    foreach ($row as $key => $value) {
                        // Exclure les champs PatientID et MedecinID
                        if ($key != 'PatientID' && $key != 'MedecinID') {
                            echo '<td onclick="get_id_patient()">' . $value . '</td>';
                        }
                    }
                    echo '<td style="display:none;">' . $row['PatientID'] . '</td>';
                    echo '</tr>';
                }

                echo '</table>';
            } else {
            ?>
                <div class="p-container">
                    <p class="message2">Vous n'avez aucun patient.</p>
                </div>
            <?php
            }
        } else {
            ?>
            <div id='admin'>
                <?php
                $tables = array("Patients", "Medecins", "PlansTraitement", "HistoriqueInjections", "ArchivePatient", "ArchiveMedecin");

                foreach ($tables as $table) {
                    $sql = "SELECT * FROM $table";
                    $result = $conn->query($sql);

                    // Vérifiez si la requête s'est exécutée avec succès
                    if ($result) {
                        if ($result->num_rows > 0) {
                            echo '<br><h2 style="text-align: center;">Table: ' . $table . '</h2>';
                            echo '<table id="' . $table . '">';
                            echo '<tr>';
                            while ($fieldinfo = $result->fetch_field()) {
                                echo '<th>' . $fieldinfo->name . '</th>';
                            }
                            echo '<th>Supprimer</th>';
                            echo '</tr>';
                            while ($row = $result->fetch_assoc()) {
                                echo '<tr>';
                                foreach ($row as $key => $value) {

                                    echo '<td contenteditable="false">' . $value . '</td>';
                                }
                                // Ajoutez une cellule cachée contenant le nom de la table
                                echo '<td style="display:none;">' . $table . '</td>';
                                $nomID;
                                $deleteTitle;
                                $desc = "";
                                switch ($table) {
                                    case 'Patients':
                                        $nomID = 'PatientID';
                                        $deleteTitle = "ce patient";
                                        $tableName = 1;
                                        $desc = "Nom";
                                        break;
                                    case 'Medecins':
                                        $nomID = 'MedecinID';
                                        $deleteTitle = "ce médecin";
                                        $tableName = 2;
                                        $desc = "nom";
                                        break;
                                    case "PlansTraitement":
                                        $nomID = "PlanID";
                                        $deleteTitle = "ce plan de traitement";
                                        $tableName = 3;
                                        $desc = $nomID;
                                        break;
                                    case "HistoriqueInjections":
                                        $nomID = "HistoryID";
                                        $deleteTitle = "cette injection";
                                        $tableName = 4;
                                        $desc = $nomID;
                                        break;
                                    case "ArchivePatient":
                                        $nomID = "ArchiveID";
                                        $deleteTitle = "ce patient archivé";
                                        $tableName = 5;
                                        $desc = "Nom";

                                        break;
                                    case "ArchiveMedecin":
                                        $nomID = "ArchiveID";
                                        $deleteTitle = "ce médecin archivé";
                                        $tableName = 6;
                                        $desc = "Nom";

                                        break;
                                }
                                echo '<td><img src="../media/trash.svg" onclick="deleteRow(' . $row[$nomID] . ', \'popup_delete_all\',' . $tableName . ',\'' . $deleteTitle . '\',\'' . $row[$desc] . '\')" alt="Image 1" width="50" height="40" style="cursor: pointer"></td>';

                                echo '</tr>';
                            }
                            echo '</table>';
                        } else {
                            echo '<p style="color: red;">Aucune donnée trouvée dans la table ' . $table . '.</p>';
                        }
                    } else {
                        // Afficher un message d'erreur si la requête échoue
                        echo '<p style="color: red;">Erreur lors de l\'exécution de la requête pour la table ' . $table . '.</p>';
                    }
                }
                ?>
            </div>
        <?php
        }
    } else {
        ?>
        <div>
            <?php
            if ($doctor_co) {
                $patientid = $_GET['patientid'];
                if ($conn->connect_error) {
                    die("Erreur de connexion à la base de données: " . $conn->connect_error);
                }

                // Récupérer les données du patient
                $info_patient_query = "SELECT * FROM Patients WHERE PatientId = '$patientid'";
                $info_patient_result = mysqli_query($conn, $info_patient_query);

                // Vérifier si la requête a retourné des résultats
                if ($info_patient_result) {
                    $reponse = mysqli_fetch_array($info_patient_result);
                    $nom_patient = isset($reponse['Nom']) ? $reponse['Nom'] : null;
                } else {
                    $nom_patient = null;
                }

                try {
                    // Exécutez la requête SQL pour récupérer l'historique des injections du patient
                    $patient_historique_query = "SELECT TempsInjection, Dose FROM HistoriqueInjections WHERE PatientId = '$patientid'";
                    $exec_patient_historique = mysqli_query($conn, $patient_historique_query);

                    if ($exec_patient_historique) {
                        if (mysqli_num_rows($exec_patient_historique) > 0) {
                            // Récupérer les données de l'historique d'injection du patient
                            // Utiliser fetch_assoc() pour obtenir un tableau associatif plutôt qu'un tableau indexé
                            $reponse_exec = mysqli_fetch_assoc($exec_patient_historique);
                            // Stocker les valeurs dans $_SESSION
                            $_SESSION['TempsInjection'] = isset($reponse_exec['TempsInjection']) ? $reponse_exec['TempsInjection'] : null;
                            $_SESSION['Dose'] = isset($reponse_exec['Dose']) ? $reponse_exec['Dose'] : null;
                        }
                    } else {
                        // Une erreur s'est produite lors de l'exécution de la requête SQL
                        echo "Une erreur s'est produite lors de la récupération des données du patient. Veuillez réessayer plus tard.";
                    }

                    // Requête pour récupérer les plans de traitement du patient
                    $patient_plan_traitement = "SELECT * FROM PlansTraitement WHERE PatientId = '$patientid'";
                    $exec_patient_plan_traitement = mysqli_query($conn, $patient_plan_traitement);

                    if ($exec_patient_plan_traitement) {
                        if (mysqli_num_rows($exec_patient_plan_traitement) > 0) {
                            // Des plans de traitement ont été trouvés
                            $no_stats = false;
                        } else {
                            // Aucun plan de traitement n'a été trouvé
                            $no_stats = true;
                        }
                    }
                } catch (Exception $e) {
                    echo 'Erreur MySQL : ' . $e->getMessage();
                }
            ?>
                <h1 style="color:#6a17bd;">Fiche patient : <?php echo $nom_patient; ?> </h1>
                <div class="button-container">
                    <button onclick="toggleBlur('popup_traitement')" class="button">Ajouter un schema basal</button>
                </div>
                <div>
                    <?php

                    $list_patient = "SELECT * FROM Patients WHERE PatientID = $patientid";

                    $resultat = $conn->query($list_patient);

                    if ($resultat->num_rows > 0) {
                        echo '<br>';
                        echo '<table id="tableau">';
                        echo '<tr>';

                        // Affichage des entêtes de colonnes
                        while ($fieldinfo = $resultat->fetch_field()) {
                            // Vérifie si le nom de la colonne est différent de PatientID et MedecinID
                            if ($fieldinfo->name != 'PatientID' && $fieldinfo->name != 'MedecinID' && $fieldinfo->name != 'Cree') {
                                echo '<th>' . $fieldinfo->name . '</th>';
                            }
                        }
                        echo '</tr>';

                        // Affichage des lignes de données
                        while ($row = $resultat->fetch_assoc()) {
                            echo '<tr>';
                            foreach ($row as $key => $value) {
                                // Vérifie si la clé est différente de PatientID et MedecinID
                                if ($key != 'PatientID' && $key != 'MedecinID' && $key != 'Cree') {
                                    echo '<td>' . $value . '</td>';
                                }
                            }
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo '<p style="color: red;">Aucun patient trouvé avec l\'identifiant spécifié.</p>';
                    }

                    // Sélectionner toutes les injections du patient
                    $list_injections = "SELECT * FROM HistoriqueInjections WHERE PatientID = $patientid";

                    $resultat_injections = $conn->query($list_injections);
                    if ($resultat_injections->num_rows > 0) {
                        echo '<br>';
                        echo '<table id="tableau">';
                        echo '<tr>';

                        // Affichage des entêtes de colonnes
                        while ($fieldinfo = $resultat_injections->fetch_field()) {
                            // Vérifie si le nom de la colonne est différent de PatientID
                            if ($fieldinfo->name != 'PatientID' &&  $fieldinfo->name != 'HistoryID') {
                                echo '<th>' . $fieldinfo->name . '</th>';
                            }
                        }
                        echo '</tr>';

                        // Affichage des lignes de données
                        while ($row = $resultat_injections->fetch_assoc()) {
                            echo '<tr>';
                            foreach ($row as $key => $value) {
                                // Vérifie si la clé est différente de PatientID
                                if ($key != 'PatientID' && $key != 'HistoryID') {
                                    echo '<td>' . $value . '</td>';
                                }
                            }
                            echo '</tr>';
                        }

                        echo '</table>';
                    } else {
                        echo '<p style="color: red;">Aucune injection trouvée pour ce patient.</p>';
                    }
                    ?>
                </div>

                <div id="chart-container" style="margin:auto; position: relative; width: 1300px; height: 1000px;">
                    <?php if (!$no_stats) {    ?>
                        <h2 style="color:#6a17bd;text-align: center;"> Plan de traitement à suivre par le patient </h2>
                        <canvas id="myChart"></canvas>
                    <?php
                    }
                    ?>
                </div>
        <?php
            }
        }
        ?>
        </div>

        <script>
            function get_id_patient() {
                var tableau = document.getElementById('tableau');
                var lignes = tableau.getElementsByTagName('tr');
                for (var i = 1; i < lignes.length; i++) {
                    lignes[i].addEventListener('click', function() {
                        var cells = this.getElementsByTagName('td');
                        var patientid = cells[8].innerText;
                        window.location.href = 'bdd.php?patientid=' + encodeURIComponent(patientid);
                    });
                }
            }

            function confirmDelete(id) {
                // Afficher la boîte de dialogue de confirmation
                var popup = document.getElementById('popup_delete_blur');
                popup.style.display = 'block';

            }

            function toggleBlur(idPopup) {
                var blur = document.getElementById("blur");
                var popup = document.getElementById(idPopup);

                if (blur.style.visibility === "hidden") {
                    blur.classList.add("blur");
                    blur.style.visibility = "visible";
                    blur.style.display = "block";
                    popup.style.display = "block";
                } else {
                    blur.classList.remove("blur");
                    blur.style.visibility = "hidden";
                    blur.style.display = "none";
                    popup.style.display = "none";
                }
            }

            function closePopup(idPopup) {
                var blur = document.getElementById("blur");
                var popup = document.getElementById(idPopup);

                blur.classList.remove("blur");
                blur.style.visibility = "hidden";
                blur.style.display = "none";
                popup.style.display = "none";
            }

            function fermerPopupEtSupprimerTraitements() {
                supprimerTraitements();
                closePopup('popup_traitement');
            }

            function deleteRow(id, idPopup, table, deleteTitle, desc) {
                var blur = document.getElementById("popup_delete_blur_all");
                var titleElement = document.getElementById("delete_popup_title");
                var popup = document.getElementById(idPopup);

                // Utilisation de balises <strong> pour mettre en gras la variable desc
                titleElement.innerHTML = "Voulez-vous vraiment supprimer " + deleteTitle + " : <strong>" + desc + "</strong> ?";

                blur.style.display = "block";
                popup.style.display = "block";
                popup.setAttribute("data-id", id);
                blur.setAttribute("data-tableNumero", table);
            }

            function confirmAllDelete() {
                var id = document.getElementById("popup_delete_all").getAttribute("data-id");
                var tableNumero = document.getElementById("popup_delete_blur_all").getAttribute("data-tableNumero");
                var xhttp = new XMLHttpRequest();
                var table = ""; // Déclaration de la variable table
                switch (tableNumero) {
                    case "1": // Assurez-vous de comparer avec une chaîne
                        table = "Patients";
                        break;
                    case "2":
                        table = "Medecins";
                        break;
                    case "3":
                        table = "PlansTraitement";
                        break;
                    case "4":
                        table = "HistoriqueInjections";
                        break;
                    case "5":
                        table = "ArchivePatient";
                        break;
                    case "6":
                        table = "ArchiveMedecin";
                        break;
                }

                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        console.log(this.responseText);
                    }
                };
                xhttp.open("POST", "delete.php", true);
                xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhttp.send("table=" + table + "&id=" + id);
                closePopup('popup_delete')
                closePopup('popup_delete_all');
                setTimeout(function() {
                    location.reload();
                }, 500); // 2000 milliseconds = 2 seconds

            }

            function supprimerTraitements() {
                var toutTraitement = document.getElementById('tout_traitement');
                toutTraitement.innerHTML = "";
            }

            function plageHoraire() {

                var toutTraitement = document.getElementById('tout_traitement');
                var dernierTraitement = toutTraitement.lastElementChild;
                var newIndex = dernierTraitement ? parseInt(dernierTraitement.id.split('_')[2]) + 1 : 1;

                var nouvellePlage = document.createElement('div');
                nouvellePlage.id = 'plage_traitement_' + newIndex;
                nouvellePlage.style.display = 'flex';
                nouvellePlage.style.flexDirection = 'row';


                nouvellePlage.innerHTML = `
    <div style="display: flex;">              
        <div style="display: flex; flex-direction: column; margin-right: 20px;">
            <label for="debut_${newIndex}">Début:</label>
            <input type="time" id="debut_${newIndex}" name="traitements[${newIndex}][debut]" min="00:00" max="24:00" value="00:00" lang="fr" style="width: 90px; -webkit-appearance: none;" required />
        </div>
        <div style="display: flex; flex-direction: column; margin-right: 20px;">
            <label for="fin_${newIndex}">Fin:</label>
            <input type="time" id="fin_${newIndex}" name="traitements[${newIndex}][fin]" min="00:00" max="24:00" value="00:00" style="width: 90px;" lang="fr" required />
        </div>
        <div style="display: flex; flex-direction: column;">
            <label for="dose_${newIndex}">Dose</label> 
            <input type="number" id="dose_${newIndex}" name="traitements[${newIndex}][dose]" min="0" max="1" step="0.01" value="0.0" style="width: 70px;" /> 
        </div>
    </div>
`;







                toutTraitement.appendChild(nouvellePlage);
            }

            function deleteTraitement(plageTraitement) {
                var x = document.getElementById(plageTraitement);
                x.remove();
            }
            // Récupérer le contexte du canvas
            var ctx = document.getElementById('myChart').getContext('2d');
            // Initialiser les tableaux labels et data
            var labels = [];
            var data = [];

            // Configurer le dataset
            var dataset = {
                label: 'Données de schéma basal',
                data: data,
                fill: false,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1
            };

            // Configurer le graphique
            var config = {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [dataset]
                },
                options: {
                    scales: {
                        x: {
                            title: {
                                display: true,
                                text: 'Heure'
                            },
                            ticks: {
                                stepSize: 1 // Définir l'espacement entre chaque repère sur l'axe des x
                            }
                        },
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Dose'
                            }
                        }
                    }
                }
            };

            // Remplir les données (exemples)
            for (var i = 0; i < 25; i++) {
                // Ajouter les données (valeurs initiales à 0 pour chaque heure)
                data.push(0);

                // Créer l'étiquette pour chaque heure
                labels.push(i.toString() + "h");
            }

            // Fonction pour mettre à jour le graphique avec les nouvelles données
            function updateChart() {
                // Effectuer une requête AJAX pour récupérer les données de la base de données
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == XMLHttpRequest.DONE) {
                        if (xhr.status == 200) {
                            // Convertir la réponse JSON en objet JavaScript
                            var result = JSON.parse(xhr.responseText);

                            // Réinitialiser les données du graphique
                            data = Array(25).fill(0);

                            if (Array.isArray(result)) {
                                // Mettre à jour les données du graphique avec les nouvelles valeurs
                                result.forEach(function(item) {
                                    // Extraire l'heure de début et de fin de chaque intervalle
                                    var heureDebut = parseInt(item.horaire_debut.split(':')[0]);
                                    var heureFin = parseInt(item.horaire_fin.split(':')[0]);

                                    // Mettre à jour les données pour chaque heure dans l'intervalle
                                    for (var i = heureDebut; i < heureFin; i++) {
                                        data[i] = item.dose;
                                    }
                                });

                                // Mettre à jour les données du dataset
                                dataset.data = data;

                                // Rafraîchir le graphique
                                myChart.update();
                            } else {
                                console.error('Le résultat de la requête n\'est pas un tableau : ', result);
                            }
                        } else {
                            console.error('Erreur lors de la requête : ' + xhr.status);
                        }
                    }
                };
                xhr.open('GET', 'infos_patient_diagramme.php?id=' + encodeURIComponent(<?php echo json_encode($_GET['patientid'] ?? ''); ?>));
                xhr.send();
            }

            // Dessiner le graphique
            var ctx = document.getElementById('myChart').getContext('2d');
            var myChart = new Chart(ctx, config);

            // Appeler la fonction updateChart pour mettre à jour le graphique initialement
            updateChart();

            function getCellData(cell) {
                var row = cell.parentNode; // Récupérer la ligne parente (tr)
                var id = row.getAttribute('id'); // Récupérer l'ID de la ligne
                console.log('ID de la ligne : ' + id);
            }



            // Fonction pour mettre à jour $isSelected côté serveur
            function updateIsSelected(value) {
                var patientAdd = document.getElementById('patientAdd');
                var formAdd = document.getElementById('formAdd');
                var formTraitement = document.getElementById('formTraitement');
                var form = document.querySelector('form');


                // Si le bouton médecin est cliqué
                if (value === 'medecin') {
                    /*                     while (patientAdd.firstChild) {
                                            patientAdd.removeChild(patientAdd.firstChild);
                                        } */
                    formTraitement.setAttribute("action", "traitement_medecin.php")
                    // Ajoutez les champs spécifiques au médecin
                    var medecinFields = `
            <label for="nom">Nom:</label>
            <input type="text" id="nom" name="nom" placeholder="Nom" required><br><br>
            <label for="prenom">Prénom:</label>
            <input type="text" id="prenom" name="prenom" placeholder="Prénom" required><br><br>
            <label for="email">Adresse E-mail:</label>
            <input type="email" id="email" name="email" placeholder="Adresse E-mail" required><br><br>
            <label for="telephone">Numéro de téléphone:</label>
            <input type="text" id="telephone" name="telephone" placeholder="Numéro de téléphone" pattern="[0-9]{10}" required>
        `;
                    // Ajoutez les champs spécifiques au médecin au formulaire
                    formAdd.innerHTML = medecinFields;
                } else {
                    formTraitement.setAttribute("action", "traitement_formulaire.php")

                    // Ajoutez les champs spécifiques au patient
                    var patientFields = `
            <label for="nom">Nom:</label>
            <input type="text" id="nom" name="nom" placeholder="Nom" required><br><br>
            <label for="prenom">Prénom:</label>
            <input type="text" id="prenom" name="prenom" placeholder="Prénom" required><br><br>
            <label for="date_naissance">Date de naissance:</label>
            <input type="date" id="date_naissance" name="date_naissance" min="1924-01-01" max="<?php echo $date_format_Ymd; ?>" required><br><br>
            <label for="email">Adresse E-mail:</label>
            <input type="email" id="email" name="email" placeholder="Adresse E-mail" required><br><br>
            <label for="telephone">Numéro de téléphone:</label>
            <input type="text" id="telephone" name="telephone" placeholder="Numéro de téléphone" pattern="[0-9]{10}" required>
        `;
                    // Ajoutez les champs spécifiques au patient au formulaire
                    formAdd.innerHTML = patientFields;
                }
            }
        </script>

        <?php
        $conn->close();
        ?>
</body>

</html>