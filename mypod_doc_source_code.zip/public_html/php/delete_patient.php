<?php
session_start();
require "../config/database.php";
$conn = getDB();
try {

    // Vérifier la connexion
    if (!$conn) {
        throw new Exception("La connexion a échoué : " . mysqli_connect_error());
    }
    $patientID = $_GET['id'];
  $requete = "INSERT INTO ArchivePatient (PatientID, MedecinID, Nom, Prenom, Naissance, Age, Adresse, Telephone, mail, Cree)
            SELECT PatientID, MedecinID, Nom, Prenom, Naissance, Age, Adresse, Telephone, mail, Cree
            FROM Patients
            WHERE PatientID = '$patientID'
            AND NOT EXISTS (
                SELECT 1 FROM ArchivePatient 
                WHERE PatientID = '$patientID'
            )";

    if (!mysqli_query($conn, $requete)) {
        throw new Exception("Erreur lors du transfert du patient vers les archives " . mysqli_error($conn));
    }
    
   // $requeteInfos = "DELETE FROM Infos WHERE PatientID = $patientID AND UserType = 'patient'";
    
    //if (!mysqli_query($conn, $requeteInfos)) {
      //  throw new Exception("Erreur lors de la suppression des informations du patient dans la table Infos : " . mysqli_error($conn//));
    //}
    
   
    $requetePlansTraitement = "DELETE FROM PlansTraitement WHERE PatientID = $patientID";
    
    if (!mysqli_query($conn, $requetePlansTraitement)) {
        throw new Exception("Erreur lors de la suppression des plans de traitement du patient dans la table PlansTraitement : " . mysqli_error($conn));
    }
    
   
    $requeteHistoriqueInjections = "DELETE FROM HistoriqueInjections WHERE PatientID = $patientID";
    
    if (!mysqli_query($conn, $requeteHistoriqueInjections)) {
        throw new Exception("Erreur lors de la suppression de l'historique des injections du patient dans la table HistoriqueInjections : " . mysqli_error($conn));
    }
    
    
    $requeteLogin = "DELETE FROM LoginPatient WHERE idpatient = $patientID";
    
    if (!mysqli_query($conn, $requeteLogin)) {
        throw new Exception("Erreur lors de la suppression des informations de connexion du patient dans la table Login : " . mysqli_error($conn));
    }
    
    $requetePatients = "DELETE FROM Patients WHERE PatientID = $patientID";

    if (!mysqli_query($conn, $requetePatients)) {
        throw new Exception("Erreur lors de la suppression des informations du patient dans la table Patients : " . mysqli_error($conn));
    }
    mysqli_close($conn);
    header('Location: bdd.php');
    exit(); 
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}
?>
