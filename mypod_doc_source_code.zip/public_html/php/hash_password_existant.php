<?php
require_once "../config/database.php"; // Inclure le fichier de configuration de la base de données

$conn = getDB(); // Établir la connexion à la base de données

// Mettre à jour les mots de passe pour les patients
$sql = "SELECT id, motdepasse FROM LoginPatient";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Récupérer le mot de passe existant
        $motdepasse = $row["motdepasse"];

        // Hasher le mot de passe
        $nouveauMotdepasse = password_hash($motdepasse, PASSWORD_DEFAULT);

        // Mettre à jour le mot de passe hashé dans la base de données
        $update_sql = "UPDATE LoginPatient SET motdepasse = '$nouveauMotdepasse' WHERE id = " . $row["id"];
        mysqli_query($conn, $update_sql);
    }
    echo "Mise à jour des mots de passe pour les patients effectuée avec succès.\n";
} else {
    echo "Aucun enregistrement trouvé dans la table LoginPatient.\n";
}

// Mettre à jour les mots de passe pour les médecins
$sql = "SELECT id, motdepasse FROM LoginMedecin";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Récupérer le mot de passe existant
        $motdepasse = $row["motdepasse"];

        // Hasher le mot de passe
        $nouveauMotdepasse = password_hash($motdepasse, PASSWORD_DEFAULT);

        // Mettre à jour le mot de passe hashé dans la base de données
        $update_sql = "UPDATE LoginMedecin SET motdepasse = '$nouveauMotdepasse' WHERE id = " . $row["id"];
        mysqli_query($conn, $update_sql);
    }
    echo "Mise à jour des mots de passe pour les médecins effectuée avec succès.\n";
} else {
    echo "Aucun enregistrement trouvé dans la table LoginMedecin.\n";
}

// Mettre à jour le mot de passe pour l'administrateur
$sql = "SELECT AdminID, PasswordHash FROM Admins";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    // Récupérer le mot de passe existant
    $motdepasseAdmin = $row["PasswordHash"];

    // Hasher le mot de passe
    $nouveauMotdepasseAdmin = password_hash($motdepasseAdmin, PASSWORD_DEFAULT);

    // Mettre à jour le mot de passe hashé dans la base de données
    $update_sql = "UPDATE Admins SET PasswordHash = '$nouveauMotdepasseAdmin' WHERE AdminID = " . $row["AdminID"];
    mysqli_query($conn, $update_sql);
    echo "Mise à jour du mot de passe de l'administrateur effectuée avec succès.\n";
    header('location: ../index.php');
} else {
    echo "Aucun enregistrement trouvé dans la table Admins.\n";
}

mysqli_close($conn); // Fermer la connexion à la base de données
?>
