<?php
// Capturez la valeur envoyée par la requête AJAX
if (isset($_POST['description'])) {
    // Assurez-vous de nettoyer et valider les données avant de les utiliser
    $popupDeleteDescription = $_POST['description'];
    // Maintenant, $popupDeleteDescription contient la description envoyée par JavaScript
} else {
    // Gérez le cas où la description n'est pas envoyée
}
