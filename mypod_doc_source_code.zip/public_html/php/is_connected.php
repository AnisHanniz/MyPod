<?php 
session_start (); 
echo isset($_SESSION['pseudo']);
?>