<?php
include("../config/database.php");
$conn = getDB();
// Assurez-vous d'avoir une connexion à la base de données ($conn) établie avant d'exécuter ce code
if ($conn->connect_error) {
    die("Erreur de connexion à la base de données: " . $conn->connect_error);
} else {

    if (isset($_POST['table']) && isset($_POST['id'])) {
        // Récupérer les données du formulaire
        $table = $_POST['table'];
        $id = $_POST['id'];
        $nomID;
        switch ($table) {
            case 'Patients':
                $nomID = 'PatientID';
                break;
            case 'Medecins':
                $nomID = 'MedecinID';

                break;
            case "PlansTraitement":
                $nomID = "PlanID";
                break;
            case "HistoriqueInjections":
                $nomID = "HistoryID";
                break;
            default:
                $nomID = "ArchiveID";
                break;
        }

        // Échapper les valeurs pour éviter les injections SQL
        $table = $conn->real_escape_string($table);
        $id = $conn->real_escape_string($id);

        // Construction de la requête de suppression
        $sql = "DELETE FROM $table WHERE $nomID = '$id'";

        // Exécution de la requête de suppression
        if ($conn->query($sql) === TRUE) {
            echo "Ligne supprimée avec succès de la table $table";
        } else {
            echo "Erreur lors de la suppression de la ligne: " . $conn->error;
        }
    } else {
        echo "Paramètres manquants";
    }
}
