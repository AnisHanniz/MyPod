<?php
session_start();
require "../config/database.php";
$conn=getDB();
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Réinitialisation de mot de passe - MyPod</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../web/style.css" />
</head>
<body>
    <div class="container">
        <div class="login-form">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <h1>Réinitialisation de mot de passe</h1>
                <div class="form-group">
                    <label for="email">Adresse E-mail :</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <button type="submit">Envoyer le code de réinitialisation</button>
                <div class="form-footer">
                    <a href="index.php">Retour à la page de connexion</a>
                </div>
            </form>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</body>
</html>

