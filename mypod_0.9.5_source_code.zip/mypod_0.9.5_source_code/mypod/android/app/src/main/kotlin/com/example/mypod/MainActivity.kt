package com.example.podapp

import android.bluetooth.*
import android.content.Context
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.IOException
import java.util.*

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.example.mypod/bluetooth"
    private val APP_NAME = "myPod"
    private val MY_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var acceptThread: AcceptThread? = null
    private var serverSocket: BluetoothServerSocket? = null
    private val connectedSockets: MutableList<BluetoothSocket> = mutableListOf()

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "connectToHost" -> {
                    val deviceAddress = call.argument<String>("deviceAddress")
                    connectToHost(deviceAddress, result)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun connectToHost(deviceAddress: String?, result: MethodChannel.Result) {
        val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            result.error("BLUETOOTH_NOT_SUPPORTED", "Bluetooth is not supported on this device", null)
            return
        }
    
        if (!bluetoothAdapter.isEnabled) {
            result.error("BLUETOOTH_NOT_ENABLED", "Bluetooth is not enabled", null)
            return
        }
    
        val device: BluetoothDevice? = bluetoothAdapter.getRemoteDevice(deviceAddress)
        if (device == null) {
            result.error("DEVICE_NOT_FOUND", "Device not found", null)
            return
        }
    
        // Attempt to connect in a background thread
        Thread(Runnable {
            var socket: BluetoothSocket? = null
            try {
                // Create and connect the socket
                socket = device.createInsecureRfcommSocketToServiceRecord(MY_UUID)
                bluetoothAdapter.cancelDiscovery() // Discovery mode is resource-intensive. Always cancel discovery before making a connection.
                socket.connect()
    
                // Connection was successful
                runOnUiThread {
                    // Use `runOnUiThread` if you need to perform any UI operations or send result back to Flutter
                    result.success("Connected to ${device.name}")
                }
            } catch (e: IOException) {
                // Connection failed
                socket?.close()
                runOnUiThread {
                    result.error("CONNECTION_FAILED", "Failed to connect to ${device.address}: ${e.message}", null)
                }
            }
        }).start()
    }

    private inner class AcceptThread(private val bluetoothAdapter: BluetoothAdapter) : Thread() {
        private val serverSocket: BluetoothServerSocket? by lazy(LazyThreadSafetyMode.NONE) {
            bluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(APP_NAME, MY_UUID)
        }
    
        override fun run() {
            // Keep listening until exception occurs or a socket is returned
            var shouldLoop = true
            while (shouldLoop) {
                val socket: BluetoothSocket? = try {
                    serverSocket?.accept()
                } catch (e: IOException) {
                    shouldLoop = false
                    null
                }
    
                socket?.also {
                    // A connection was accepted. Perform work associated with
                    // the connection in a separate thread.
                    manageConnectedSocket(it)
                    serverSocket?.close()
                    shouldLoop = false
                }
            }
        }
    
        fun cancel() {
            try {
                serverSocket?.close()
            } catch (e: IOException) {
            }
        }
    }
    
    private fun manageConnectedSocket(socket: BluetoothSocket) {
        // Handle the connection in a separate thread or service
        // You might want to pass the socket to another thread to perform
        // I/O operations like reading and writing
    }
}
