package com.example.mypod

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
