import 'dart:convert';

import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mypod/pages/bdd/database.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:mypod/utils/app_constants.dart';
import 'package:mypod/utils/app_routes.dart';
import 'package:mypod/widgets/Custom_diWHise/custom_text_form_field.dart';
import 'package:provider/provider.dart';

Future<String?> login(String email, String password, AppState appState) async {
  try {
    final response = await http.post(
      Uri.parse('https://mypodev.000webhostapp.com/API/auth/login.php'),
      body: {
        'mail': email,
        'password': password,
      },
    );

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);

      if (data['success'] == true) {
        String token = data['token'];

        if (data.containsKey('id')) {
          int id = data['id'];

          appState.token = token;
          appState.id = id;
          appState.mail = email;

          double defaultValue = 0;
          await DatabaseProvider().insertOrUpdateUtilisateurParams(
            id,
            email,
            token,
            defaultValue,
          );

          return token;
        } else {
          throw Exception('ID non trouvé dans la réponse JSON');
        }
      } else {
        throw Exception('Échec de connexion: ${data['message']}');
      }
    } else {
      throw Exception(
          'Erreur de communication avec l\'API: ${response.statusCode}');
    }
  } catch (error) {
    print('Erreur lors de la connexion: $error');
    throw Exception('Erreur lors de la connexion: $error');
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    AppState appState = Provider.of<AppState>(context, listen: false);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 70),
                _buildPageTitle(),
                const SizedBox(height: 32),
                CustomTextFormField(
                  controller: emailController,
                  hintText: "Votre mail",
                  textInputType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Veuillez entrer votre email';
                    }
                    if (!EmailValidator.validate(value)) {
                      return 'Entrez un email valide';
                    }
                    return null;
                  },
                  prefix: const Icon(Icons.email, color: Colors.grey),
                ),
                const SizedBox(height: 16),
                CustomTextFormField(
                  controller: passwordController,
                  hintText: "Mot de Passe",
                  textInputAction: TextInputAction.done,
                  textInputType: TextInputType.visiblePassword,
                  obscureText: !_isPasswordVisible,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Le mot de passe ne peut pas être vide';
                    }
                    return null;
                  },
                  prefix: const Icon(Icons.lock, color: Colors.grey),
                  suffix: IconButton(
                    onPressed: () {
                      setState(() {
                        _isPasswordVisible = !_isPasswordVisible;
                      });
                    },
                    icon: Icon(_isPasswordVisible
                        ? Icons.visibility
                        : Icons.visibility_off),
                  ),
                ),
                const SizedBox(height: 32),
                _isLoading
                    ? const CircularProgressIndicator()
                    : ElevatedButton(
                        onPressed: () async {
                          if (_formKey.currentState!.validate()) {
                            setState(() => _isLoading = true);
                            try {
                              var loginResult = await login(
                                emailController.text,
                                passwordController.text,
                                appState,
                              );
                              String? token = loginResult.toString();

                              print('Token: $token');

                              await DatabaseProvider().createAllTables();

                              Provider.of<AppState>(
                                context,
                                listen: false,
                              ).token = token;
                              Provider.of<AppState>(
                                context,
                                listen: false,
                              ).mail = emailController.text;

                              await Future.delayed(Duration.zero);

                              Navigator.pushNamed(
                                context,
                                AppRoutes.accueilScreen,
                              );
                            } catch (error) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Erreur: $error')),
                              );
                            } finally {
                              setState(() => _isLoading = false);
                            }
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          minimumSize: const Size(double.infinity, 50),
                        ),
                        child: const Text(
                          "Se connecter",
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                const SizedBox(height: 28),
                GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      AppRoutes.signupScreen,
                    );
                  },
                  child: RichText(
                    text: TextSpan(
                      children: [
                        const TextSpan(
                          text: "Première connexion? ",
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.black,
                          ),
                        ),
                        TextSpan(
                          text: "S'enregistrer",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppConstants.violet,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      AppRoutes.forgotPasswordScreen,
                    );
                  },
                  child: RichText(
                    text: TextSpan(
                      children: [
                        const TextSpan(
                          text: "Mot de passe oublié? ",
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.black,
                          ),
                        ),
                        TextSpan(
                          text: "Réinitialiser",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: AppConstants.violet,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPageTitle() {
    return Column(
      children: [
        Image.asset(
          AppConstants.imageLogo,
          height: 100,
          width: 100,
        ),
        const SizedBox(height: 26),
        const Text(
          "Bienvenue sur MyPod",
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          "Se Connecter pour continuer",
          style: TextStyle(
            fontSize: 16,
            color: Colors.black,
          ),
        ),
      ],
    );
  }
}
