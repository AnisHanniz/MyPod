import 'dart:async';

import 'package:flutter/material.dart';
import 'package:mypod/utils/app_constants.dart';
import 'package:mypod/utils/app_routes.dart';
import 'package:mypod/widgets/Custom_diWHise/custom_elevated_button.dart';
import 'package:mypod/widgets/Custom_diWHise/custom_outlined_button.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  int _currentPageIndex = 0;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(_animationController);

    // Ajout d'un délai avant de passer à la deuxième page
    Timer(const Duration(seconds: 1), () {
      setState(() {
        _currentPageIndex = 1;
      });
    });

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onTapLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginScreen);
  }

  void _onTapSignUp(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signupScreen);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: AnimatedBuilder(
        animation: _fadeAnimation,
        builder: (context, child) {
          return Opacity(
            opacity: _fadeAnimation.value,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: PageView(
                      physics:
                          const NeverScrollableScrollPhysics(), // Désactiver le défilement
                      children: [
                        _buildSplashPage(
                          image: AppConstants.imageLogo,
                          description: "",
                        ),
                        _buildSplashPage(
                          image: AppConstants.imageLogo,
                          description: "",
                        ),
                      ],
                    ),
                  ),
                  if (_currentPageIndex == 1) ...[
                    const SizedBox(height: 20),
                    CustomElevatedButton(
                      text: "Se Connecter",
                      onPressed: () {
                        _onTapLogin(context);
                      },
                    ),
                    const SizedBox(height: 10),
                    CustomOutlinedButton(
                      text: "Première Connexion",
                      onPressed: () {
                        _onTapSignUp(context);
                      },
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSplashPage({
    required String image,
    required String description,
  }) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          image,
          height: 400,
          width: 400,
        ),
        const SizedBox(height: 20),
        Text(
          description,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ],
    );
  }
}
