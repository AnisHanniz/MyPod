import 'dart:convert';

import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mypod/utils/app_constants.dart';
import 'package:mypod/widgets/Custom_diWHise/custom_elevated_button.dart';
import 'package:mypod/widgets/Custom_diWHise/custom_image_view.dart';
import 'package:mypod/widgets/Custom_diWHise/custom_text_form_field.dart';

class FirstConnectionScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  FirstConnectionScreen({super.key});

  Future<void> resetPassword(BuildContext context, String email) async {
    final response = await http.post(
      Uri.parse(
          'https://mypodev.000webhostapp.com/API/auth/reset_password.php'),
      body: {'mail': email},
    );

    print('Response status code: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      if (data.containsKey('message') &&
          data['message'].contains('réinitialisation')) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Un email de réinitialisation a été envoyé.'),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Erreur lors de l\'envoi de l\'email. Faites une demande auprès de votre médecin.',
            ),
          ),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Erreur de communication avec l\'API'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 70),
                buildPageTitle(),
                const SizedBox(height: 32),
                CustomTextFormField(
                  controller: emailController,
                  hintText: "Votre mail",
                  textInputType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Veuillez entrer votre email';
                    }
                    if (!EmailValidator.validate(value)) {
                      return 'Entrez un email valide';
                    }
                    return null;
                  },
                  prefix: const Icon(Icons.email, color: Colors.grey),
                ),
                const SizedBox(height: 32),
                CustomElevatedButton(
                  text: "Obtenir un Mot de Passe",
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      await resetPassword(context, emailController.text);
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildPageTitle() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        CustomImageView(
          imagePath: AppConstants.imageLogo,
          height: 125,
          width: 125,
        ),
        const SizedBox(height: 26),
        const Text(
          "Première Connexion",
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        const Text(
          "Entrez votre adresse e-mail pour obtenir un mot de passe",
          style: TextStyle(
            fontSize: 16,
            color: Colors.black,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
