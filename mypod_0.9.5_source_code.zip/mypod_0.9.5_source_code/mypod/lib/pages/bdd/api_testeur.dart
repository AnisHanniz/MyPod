import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ApiTester extends StatefulWidget {
  const ApiTester({super.key});

  @override
  State<ApiTester> createState() => _ApiTesterState();
}

class _ApiTesterState extends State<ApiTester> {
  final TextEditingController _resultController = TextEditingController();

  Future<void> fetchInfosPatient() async {
    final response = await http.get(Uri.parse(
        'https://mypodev.000webhostapp.com/API/patient.php?email=hanniz.n.anis@gmail.com'));
    if (response.statusCode == 200) {
      _resultController.text = response.body;
    } else {
      _resultController.text =
          'Erreur lors de la récupération des infos patient.';
    }
  }

  Future<bool> login(String email, String password) async {
    final response = await http.post(
      Uri.parse(
          'https://mypodev.000webhostapp.com/API/auth/login.php'), // remove extra slashes
      body: {
        'mail': email, // use 'email' instead of 'mail'
        'password': password, // 'password' remains the same
      },
    );

    print('Response status code: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      return data['success'];
    } else {
      throw Exception('Erreur de communication avec l\'API');
    }
  }

  Future<void> fetchTraitementPatient() async {
    final response =
        await http.get(Uri.parse(
	'https://mypodev.000webhostapp.com/API/schema_basaux/schema.php'));
    if (response.statusCode == 200) {
      _resultController.text = response.body;
    } else {
      _resultController.text =
          'Erreur lors de la récupération des traitements patient.';
    }
  }

  Future<void> resetPassword(BuildContext context, String email) async {
    final response = await http.post(
      Uri.parse(
          'https://mypodev.000webhostapp.com/API/auth/reset_password.php'),
      body: {'mail': email},
    );

    print('Response status code: ${response.statusCode}');
    print('Response body: ${response.body}');

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      if (data['success'] != null && data['success']) {
        // Si la réinitialisation du mot de passe réussit
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Un email de réinitialisation a été envoyé.')),
        );
        // Extraire le nouveau mot de passe de la réponse de l'API
        String newPassword = data['new_password'];
        // Mettre à jour la zone de texte avec le nouveau mot de passe
        _resultController.text = 'Nouveau mot de passe : $newPassword';
      }
    } else {
      // En cas d'erreur de communication avec l'API
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur de communication avec l\'API')),
      );
    }
  }

  @override
  void dispose() {
    _resultController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Testeur d\'API'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: fetchInfosPatient,
              child: const Text('Infos Patient'),
            ),
            ElevatedButton(
              onPressed: fetchTraitementPatient,
              child: const Text('Traitement Patient'),
            ),
            ElevatedButton(
              onPressed: fetchTraitementPatient,
              child: const Text('Envoi Historique'),
            ),
            ElevatedButton(
              onPressed: () {
                resetPassword(context, "hanniz.n.anis@gmail.com");
              },
              child: const Text('Réinitialiser Mdp Patient1'),
            ),
            ElevatedButton(
              onPressed: () async {
                bool success =
                    await login("patient1@example.com", "motdepasse1");
                if (success) {
                  _resultController.text = 'Connexion réussie';
                } else {
                  _resultController.text = 'Identifiants incorrects';
                }
              },
              child: const Text('Test Login Patient 1'),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _resultController,
              maxLines:
                  null, // Permet au TextField de s'étendre sur plusieurs lignes
              decoration: const InputDecoration(
                labelText: 'Résultat',
                border: OutlineInputBorder(),
              ),
              readOnly: true, // Rend le TextField en lecture seule
            ),
          ],
        ),
      ),
    );
  }
}
