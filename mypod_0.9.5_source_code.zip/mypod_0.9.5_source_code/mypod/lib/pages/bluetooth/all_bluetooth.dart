import 'package:all_bluetooth/all_bluetooth.dart';
import 'package:flutter/material.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:mypod/utils/app_constants.dart';
import 'package:permission_handler/permission_handler.dart';

class AccueilBluetooth extends StatefulWidget {
  const AccueilBluetooth({super.key});

  @override
  State<AccueilBluetooth> createState() => _AccueilBluetoothState();
}

class _AccueilBluetoothState extends State<AccueilBluetooth> {
  final bondedDevices = ValueNotifier(<BluetoothDevice>[]);

  bool isListening = false;
  @override
  void initState() {
    super.initState();
    AppStateBluetooth.allBluetooth = AllBluetooth();

    Future.wait([
      Permission.bluetooth.request(),
      Permission.bluetoothScan.request(),
      Permission.bluetoothConnect.request(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: AppStateBluetooth.allBluetooth.streamBluetoothState,
        builder: (context, snapshot) {
          final bluetoothOn = snapshot.data ?? false;

          return Scaffold(
            appBar: AppBar(
              title: const Text("Bluetooth Connect"),
            ),
            // floatingActionButton: switch (isListening) {
            //   true => null,
            //   false => FloatingActionButton(
            //       onPressed: switch (bluetoothOn) {
            //         false => null,
            //         true => () {
            //             AppStateBluetooth.allBluetooth.startBluetoothServer();
            //             print("Le serveur est en écoute");
            //             setState(() => isListening = true);
            //           },
            //       },
            //       backgroundColor: bluetoothOn
            //           ? Theme.of(context).primaryColor
            //           : Colors.grey,
            //       child: const Icon(Icons.wifi_tethering),
            //     ),
            // },
            body: isListening
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Écoute de connexions en cours ..."),
                        const CircularProgressIndicator(),
                        FloatingActionButton(
                          child: const Icon(Icons.stop),
                          onPressed: () {
                            AppStateBluetooth.allBluetooth.closeConnection();
                            print("Le serveur n'est plus en écoute");
                            setState(() {
                              isListening = false;
                            });
                          },
                        )
                      ],
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              switch (bluetoothOn) {
                                true => "Bluetooth Activé",
                                false => "Bluetooth Désactivé",
                              },
                              style: TextStyle(
                                  color: bluetoothOn
                                      ? AppConstants.violet
                                      : Colors.red),
                            ),
                            ElevatedButton(
                              onPressed: switch (bluetoothOn) {
                                false => null,
                                true => () async {
                                    final devices = await AppStateBluetooth
                                        .allBluetooth
                                        .getBondedDevices();
                                    bondedDevices.value = devices;
                                  },
                              },
                              child: const Text("Périphériques appairés"),
                            ),
                          ],
                        ),
                        if (!bluetoothOn)
                          const Center(
                            child: Text("Activer le bluetooth"),
                          ),
                        ValueListenableBuilder(
                            valueListenable: bondedDevices,
                            builder: (context, devices, child) {
                              return Expanded(
                                child: ListView.builder(
                                  itemCount: bondedDevices.value.length,
                                  itemBuilder: (context, index) {
                                    final device = devices[index];
                                    return ListTile(
                                      title: Text(device.name),
                                      subtitle: Text(device.address),
                                      onTap: () {
                                        AppStateBluetooth.allBluetooth
                                            .connectToDevice(device.address);
                                        print(
                                            "Tentative de connexion à : ${device.address}");
                                      },
                                    );
                                  },
                                ),
                              );
                            })
                      ],
                    ),
                  ),
          );
        });
  }
}
