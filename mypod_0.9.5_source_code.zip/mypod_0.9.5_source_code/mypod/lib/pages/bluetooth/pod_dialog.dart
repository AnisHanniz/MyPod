import 'package:flutter/material.dart';
import 'package:mypod/pages/bluetooth/all_bluetooth.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:mypod/utils/app_constants.dart';

void showChangePodDialog(BuildContext context, Function launchBluetoothState) {
  final PageController controller = PageController();
  int currentPageIndex = 0;

  showDialog(
    context: context,
    builder: (BuildContext context) {
      final List<Widget> pages = [
        const StepPage(
          title: "Retirer le Pod actuel",
          content:
              "Retirer puis éliminez votre Pod actuel.\n\n (Si vous utilisez PodApp, veuillez rafraîchir.)",
        ),
        const StepPage(
          title: "Activer le Bluetooth",
          content: "Activez le bluetooth sur votre appareil.",
        ),
        const StepPage(
          title: "Appairage à la pompe",
          content:
              "Sélectionner le bon périphérique à appairer grâce au Bluetooth de votre téléphone.",
        ),
        const StepPage(
          title: "Connexion à la pompe",
          content:
              "Mettre le nouveau pod en 'Mode Écoute'\n\nPuis séléctionnez ensuite la pompe pour de vous y connecter !",
        ),
      ];

      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return AlertDialog(
            contentPadding: EdgeInsets.zero,
            content: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.6,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: PageView.builder(
                      controller: controller,
                      itemCount: pages.length,
                      itemBuilder: (context, index) {
                        return Container(
                          padding: const EdgeInsets.all(20.0),
                          child: pages[index],
                        );
                      },
                      onPageChanged: (int index) {
                        setState(() {
                          currentPageIndex = index;
                        });
                      },
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                    child: AnimatedBuilder(
                      animation: controller,
                      builder: (context, child) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(
                            pages.length,
                            (index) => Container(
                              width: 10.0,
                              height: 10.0,
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 5.0),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: index == currentPageIndex
                                    ? AppConstants.violet
                                    : Colors.grey,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            actions: <Widget>[
              Align(
                alignment: Alignment.center,
                child: Visibility(
                  visible: currentPageIndex == pages.length - 1,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      Future.delayed(Duration.zero, () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const AppStateBluetooth()),
                        );
                      });
                    },
                    child: const Text("Se connecter à un Pod"),
                  ),
                ),
              ),
            ],
          );
        },
      );
    },
  );
}

class StepPage extends StatelessWidget {
  final String title;
  final String content;

  const StepPage({
    super.key,
    required this.title,
    required this.content,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        ListTile(
          leading: const Icon(Icons.arrow_forward),
          title: Text(title),
        ),
        const SizedBox(
          height: 20.0,
        ), // Ajout d'un espace entre l'image et le texte
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(
            content,
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}

void launchPumpState(BuildContext context) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (BuildContext context) => const AccueilBluetooth(),
    ),
  );
}
