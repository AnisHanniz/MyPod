import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:provider/provider.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => ChatScreenState();
}

class ChatScreenState extends State<ChatScreen> {
  final messageController = TextEditingController();

  final messages = <Message>[];

  Timer? _timer;

  @override
  void initState() {
    super.initState();

    final appState = Provider.of<AppState>(context, listen: false);
    appState.isConnectedToPump = true;
    //AppStateBluetooth.isConnectedToPump = true;
    AppStateBluetooth.allBluetooth.listenForData.listen(onDataReceived);
    Timer.periodic(const Duration(seconds: 5), (timer) {
      if (!appState.isConnectedToPump) {
        timer.cancel(); // Arrête le timer si isConnectedToPump devient faux
        AppStateBluetooth.allBluetooth.closeConnection();
      } else {
        _startRefreshTimer(); // Exécute la tâche toutes les 5 secondes
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    messageController.dispose();
    AppStateBluetooth.allBluetooth.closeConnection();
  }

  void _startRefreshTimer() {
    final appState = Provider.of<AppState>(context, listen: false);
    _timer = Timer.periodic(const Duration(seconds: 5), (Timer timer) {
      Timer.periodic(const Duration(seconds: 5), (timer) {
        if (!appState.isConnectedToPump) {
          timer.cancel(); // Arrête le timer si isConnectedToPump devient faux
          _stopRefreshTimer();
        } else {
          sendBasal(); // Exécute la tâche toutes les 5 secondes
        }
      });
    });
  }

  void _stopRefreshTimer() {
    AppStateBluetooth.allBluetooth.closeConnection();
    _timer?.cancel();
  }

  void onDataReceived(dynamic event) {
    String message = event.toString();

    void showDescriptionSnackBar(String description) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(description),
          duration: const Duration(seconds: 5), // Durée de la SnackBar
        ),
      );
    }

    if (isInsulinRemaining(message)) {
      // showDescriptionSnackBar("Mise à jour de l'insuline restante.");
      print("Mise à jour de l'insuline restante.");
    }
    if (isLifeTime(message)) {
      print("Mise à jour de la durée de vie restante.");
      //showDescriptionSnackBar("Mise à jour de la durée de vie restante.");
    }

    messages.add(Message(
      message: message,
      isMe: false,
    ));
    setState(() {});
  }

  Future<void> sendBolus(double qt) async {
    try {
      // Envoyer la chaîne JSON
      AppStateBluetooth.allBluetooth.sendMessage("bolus: ${qt.toString()}");

      // Ajouter les détails du schéma basal à une liste de messages si nécessaire

      final message = "bolus: ${qt.toString()}";
      messages.add(Message(
        message: message,
        isMe: true,
      ));

      setState(() {});
    } catch (e) {
      print('Error sending schema basal: $e');
    }
  }

  Future<void> sendBasal() async {
    try {
      final appState = Provider.of<AppState>(context, listen: false);
      final basalEnCours = appState.basalEnCours;

      // Envoyer la chaîne JSON
      AppStateBluetooth.allBluetooth
          .sendMessage("basalEnCours: ${basalEnCours.toString()}");

      // Ajouter les détails du schéma basal à une liste de messages si nécessaire

      final message = "basalEnCours: ${basalEnCours.toString()}";
      messages.add(Message(
        message: message,
        isMe: true,
      ));

      setState(() {});
    } catch (e) {
      print('Error sending schema basal: $e');
    }
  }

  bool isInsulinRemaining(String message) {
    final appState = Provider.of<AppState>(context, listen: false);
    RegExp regExp = RegExp(r'^inslulinRemaining: (\d+(\.\d+)?)$');
    Match? match = regExp.firstMatch(message);
    if (match != null) {
      print("isInsulinRemaining match");
      String value = match.group(
          1)!; // Obtenez la valeur correspondante sans 'insulinRemaining:'
      print("Valeur d'insuline restante : $value");
      appState.insulinRemaining = double.parse(value);
      return true;
    } else {
      return false;
    }
  }

  bool isLifeTime(String message) {
    final appState = Provider.of<AppState>(context, listen: false);
    RegExp regExp = RegExp(r'^lifeTime: (\d+(\.\d+)?)$');
    Match? match = regExp.firstMatch(message);
    if (match != null) {
      print("lifeTime match");
      String value = match.group(
          1)!; // Obtenez la valeur correspondante sans 'insulinRemaining:'
      print("lifeTime valeur : $value");
      appState.podLifetime = double.parse(value);
      return true;
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          ElevatedButton(
            onPressed: () {
              AppStateBluetooth.allBluetooth.closeConnection();
            },
            child: const Text("Se déconnecter"),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ChatBubble(
                    clipper: ChatBubbleClipper4(
                      type: message.isMe
                          ? BubbleType.sendBubble
                          : BubbleType.receiverBubble,
                    ),
                    alignment:
                        message.isMe ? Alignment.topRight : Alignment.topLeft,
                    child: Text(message.message),
                  ),
                );
              },
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: messageController,
                  decoration: const InputDecoration(
                    enabledBorder: OutlineInputBorder(),
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  final message = messageController.text;
                  AppStateBluetooth.allBluetooth.sendMessage(message);
                  messageController.clear();
                  messages.add(
                    Message(
                      message: message,
                      isMe: true,
                    ),
                  );
                  setState(() {});
                },
                icon: const Icon(Icons.send),
              ),
              IconButton(
                onPressed: () {
                  sendBasal();
                },
                icon: const Icon(Icons.upload),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class Message {
  final String message;
  final bool isMe;

  Message({required this.message, required this.isMe});
}
