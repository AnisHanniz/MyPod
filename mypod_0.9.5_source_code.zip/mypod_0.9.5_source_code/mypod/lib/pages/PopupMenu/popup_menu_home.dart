import 'package:flutter/material.dart';
import 'package:mypod/pages/PopupMenu/Sch%C3%A9masBasaux/popup_basal_temp.dart';
import 'package:mypod/pages/PopupMenu/Sch%C3%A9masBasaux/popup_basal_temp_liste.dart';
import 'package:mypod/pages/PopupMenu/Sch%C3%A9masBasaux/popup_basaux.dart';
import 'package:mypod/pages/PopupMenu/popup_about.dart';
import 'package:mypod/pages/PopupMenu/popup_historique.dart';
import 'package:mypod/pages/PopupMenu/popup_infos_perso.dart';
import 'package:mypod/pages/PopupMenu/popup_pod.dart';
import 'package:mypod/pages/PopupMenu/popup_rappels.dart';
import 'package:mypod/pages/PopupMenu/popup_reglages.dart';
import 'package:mypod/pages/bdd/database.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:provider/provider.dart';

class MyPopupMenu extends StatelessWidget {
  const MyPopupMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      onSelected: (value) {
        if (value == 'menu_basal_temp') {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return const BasalTempPage();
            },
          );
        } else if (value == 'menu_infos_perso') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const InfosPerso(),
            ),
          );
        } else if (value == 'menu_pod') {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return const Dialog(
                child: PodPage(),
              );
            },
          );
        } else if (value == 'menu_historique') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const InjectionPage(),
            ),
          );
        } else if (value == 'menu_about') {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return const PopupAbout();
            },
          );
        } else if (value == 'menu_reglages') {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return const SettingsPopup();
            },
          );
        } else if (value == 'menu_prog_basaux') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  PopupBasaux(databaseProvider: DatabaseProvider()),
            ),
          );
        } else if (value == 'menu_profils_basaux') {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const ListeProfilsBasaux(),
            ),
          );
        } else if (value == 'menu_suspendre_insuline') {
          _confirmSuspendInsuline(context);
        } else if (value == 'menu_rappels') {
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return const NotificationSettingsPage();
              });
        }
      },
      itemBuilder: (BuildContext context) {
        return <PopupMenuEntry<String>>[
          const PopupMenuItem<String>(
            value: 'menu_infos_perso',
            child: ListTile(
              leading: Icon(Icons.person),
              title: Text('Informations Personnelles'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_basal_temp',
            child: ListTile(
              leading: Icon(Icons.lock_clock),
              title: Text('Définir Basal Temporaire'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_profils_basaux',
            child: ListTile(
              leading: Icon(Icons.list),
              title: Text('Liste Profils Basaux'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_pod',
            child: ListTile(
              leading: Icon(Icons.smartphone),
              title: Text('Pod'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_suspendre_insuline',
            child: ListTile(
              leading: Icon(Icons.stop),
              title: Text('Suspendre Admin. Insuline'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_prog_basaux',
            child: ListTile(
              leading: Icon(Icons.schema_rounded),
              title: Text('Programmes Basaux'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_historique',
            child: ListTile(
              leading: Icon(Icons.history),
              title: Text("Historique d'injections"),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_rappels',
            child: ListTile(
              leading: Icon(Icons.notifications),
              title: Text('Rappels'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_reglages',
            child: ListTile(
              leading: Icon(Icons.settings),
              title: Text('Réglages'),
            ),
          ),
          const PopupMenuItem<String>(
            value: 'menu_about',
            child: ListTile(
              leading: Icon(Icons.info),
              title: Text('À propos'),
            ),
          ),
        ];
      },
    );
  }

  // Méthode pour afficher une boîte de dialogue de confirmation

  void _confirmSuspendInsuline(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirmation'),
          content: const Text(
              'Êtes-vous sûr de vouloir suspendre l\'administration d\'insuline ?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Annuler'),
            ),
            TextButton(
              onPressed: () {
                final appState = Provider.of<AppState>(context, listen: false);
                appState.basalEnCours = 0;
                Navigator.of(context).pop();
              },
              child: const Text('Confirmer'),
            ),
          ],
        );
      },
    );
  }
}
