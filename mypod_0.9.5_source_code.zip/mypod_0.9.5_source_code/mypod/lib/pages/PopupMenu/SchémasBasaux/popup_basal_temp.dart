import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

class BasalTempPage extends StatefulWidget {
  const BasalTempPage({super.key});

  @override
  _BasalTempPageState createState() => _BasalTempPageState();
}

class _BasalTempPageState extends State<BasalTempPage> {
  double selectedDuration = 0.25;
  TextEditingController basalRateController = TextEditingController();
  TextEditingController profileNameController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String formatDuration(double value) {
    int hours = value.floor();
    int minutes = ((value - hours) * 60).toInt();

    if (hours == 0) {
      return '$minutes min';
    } else if (minutes == 0) {
      return '$hours h';
    } else {
      return '$hours h $minutes min';
    }
  }

  void _showSnackbar(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _createTemporaryBasalProfile() async {
    if (_formKey.currentState?.validate() ?? false) {
      double basalRate = double.parse(basalRateController.text);
      String profileName = profileNameController.text;

      Directory? appDocDir = await getApplicationDocumentsDirectory();
      String profilesDirPath = '${appDocDir.path}/basal_profiles';
      Directory profilesDir = Directory(profilesDirPath);
      if (!await profilesDir.exists()) {
        await profilesDir.create(recursive: true);
      }

      String profileFileName =
          '${profileName.replaceAll(' ', '_')}.txt'; // Only file name with .txt extension

      String profileFilePath = '${profilesDir.path}/$profileFileName';
      print(profileFilePath);
      // Write the basal profile to the file
      File profileFile = File(profileFilePath);
      await profileFile.writeAsString('Profile Name: $profileName\n');
      await profileFile.writeAsString('Duration: $selectedDuration hours\n',
          mode: FileMode.append);
      await profileFile.writeAsString(
          'Basal Rate: ${basalRate.toStringAsFixed(2)} units per hour\n',
          mode: FileMode.append);

      _showSnackbar('Profil temporaire créé');

      //final appState = Provider.of<AppState>(context, listen: false);
      //double oldBasalEnCours = appState.basalEnCours;
      //appState.basalEnCours = basalRate;
      /*
      Timer(Duration(hours: selectedDuration.toInt()), () {
        //profileFile.delete();
        appState.basalEnCours = oldBasalEnCours;
        _showSnackbar('Profil temporaire expiré');
      });*/
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Padding(
        padding: EdgeInsets.all(10.0),
        child: Text(
          'Définir Basal Temporaire',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          textAlign: TextAlign.center,
        ),
      ),
      content: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Row(
                children: [
                  Icon(Icons.description),
                  SizedBox(width: 10.0),
                  Text(
                    'Nom du profil basal:',
                    style: TextStyle(fontSize: 14.0),
                  ),
                ],
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                controller: profileNameController,
                decoration: const InputDecoration(
                  hintText: 'Entrez le nom du profil',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer un nom';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20.0),
              const Row(
                children: [
                  Icon(Icons.access_time),
                  SizedBox(width: 10.0),
                  Flexible(
                    child: Text(
                      'Durée :',
                      style: TextStyle(fontSize: 14.0),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10.0),
              Slider(
                value: selectedDuration,
                onChanged: (value) {
                  setState(() {
                    selectedDuration = value;
                  });
                },
                min: 0,
                max: 3.0,
                divisions: 12,
                label: formatDuration(selectedDuration),
              ),
              SizedBox(
                height: 20.0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(formatDuration(0)),
                    Text(formatDuration(3.0)),
                  ],
                ),
              ),
              const SizedBox(height: 20.0),
              const Row(
                children: [
                  SizedBox(width: 10.0),
                  Flexible(
                    child: Text(
                      'Quantité (unités/h):',
                      style: TextStyle(fontSize: 14.0),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                controller: basalRateController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: 'Entrez la quantité basale',
                  border: const OutlineInputBorder(),
                  errorText: (_formKey.currentState?.validate() ?? true)
                      ? null
                      : 'Veuillez entrer des valeurs correctes !',
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer une valeur';
                  }
                  double? parsedValue = double.tryParse(value);
                  if (parsedValue == null ||
                      parsedValue < 0 ||
                      parsedValue > 1) {
                    return 'Veuillez entrer une valeur entre 0 et 1';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        ElevatedButton(
          onPressed: _createTemporaryBasalProfile,
          child: const Text(
            'Créer',
            textAlign: TextAlign.center,
          ),
        ),
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text(
            'Fermer',
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    basalRateController.dispose();
    profileNameController.dispose();
    super.dispose();
  }
}
