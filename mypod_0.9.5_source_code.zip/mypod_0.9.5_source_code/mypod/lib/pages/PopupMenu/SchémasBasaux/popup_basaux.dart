import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mypod/pages/bdd/database.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:provider/provider.dart';

class PopupBasaux extends StatefulWidget {
  final DatabaseProvider databaseProvider;

  const PopupBasaux({super.key, required this.databaseProvider});

  @override
  _PopupBasauxState createState() => _PopupBasauxState();
}

class _PopupBasauxState extends State<PopupBasaux> {
  late Future<List<DataPoint>> _schemaBasalDataFuture;

  Future<List<DataPoint>> _fetchSchemaBasal(String id) async {
    const url =
        'https://mypodev.000webhostapp.com/API/schema_basaux/schema.php';
    final response = await http.post(Uri.parse(url), body: {
      'id': id,
    });

    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      return _parseSchemaBasal(responseData);
    } else {
      throw Exception('Failed to load schema basal');
    }
  }

  List<DataPoint> _parseSchemaBasal(dynamic data) {
    List<DataPoint> points = [];
    for (var item in data) {
      try {
        List<String> heureDebutParts =
            (item['horaire_debut'] ?? '00:00:00').split(':');
        List<String> heureFinParts =
            (item['horaire_fin'] ?? '00:00:00').split(':');

        TimeOfDay heureDebut = TimeOfDay(
          hour: int.parse(heureDebutParts[0]),
          minute: int.parse(heureDebutParts[1]),
        );

        TimeOfDay heureFin = TimeOfDay(
          hour: int.parse(heureFinParts[0]),
          minute: int.parse(heureFinParts[1]),
        );

        double dose = double.tryParse(item['dose'] ?? '0') ?? 0;
        points.add(DataPoint(heureDebut, heureFin, dose));
      } catch (e) {
        print('Error parsing data: $e');
      }
    }
    return points;
  }

  @override
  void initState() {
    super.initState();
    final appState = Provider.of<AppState>(context, listen: false);
    _schemaBasalDataFuture = _fetchSchemaBasal(appState.id.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Schéma Basal'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const SizedBox(height: 20),
            Expanded(
              child: FutureBuilder<List<DataPoint>>(
                future: _schemaBasalDataFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else if (snapshot.hasData) {
                    return Center(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: DataTable(
                          columns: const [
                            DataColumn(label: Text('Heure début')),
                            DataColumn(label: Text('Heure fin')),
                            DataColumn(label: Text('Dose')),
                          ],
                          rows: snapshot.data!.map((dataPoint) {
                            return DataRow(
                              cells: [
                                DataCell(
                                  Text(dataPoint.heureDebut.format(context)),
                                ),
                                DataCell(
                                  Text(dataPoint.heureFin.format(context)),
                                ),
                                DataCell(
                                  Text(dataPoint.dose.toString()),
                                ),
                              ],
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  } else {
                    return const SizedBox.shrink();
                  }
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {
                final appState = Provider.of<AppState>(context, listen: false);
                setState(() {
                  _schemaBasalDataFuture =
                      _fetchSchemaBasal(appState.id.toString());
                });
              },
              child: const Icon(Icons.refresh),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Fermer'),
            ),
          ],
        ),
      ),
    );
  }
}

class DataPoint {
  final TimeOfDay heureDebut;
  final TimeOfDay heureFin;
  final double dose;

  DataPoint(this.heureDebut, this.heureFin, this.dose);

Map<String, dynamic> toJson() {
    return {
      'heureDebut': heureDebut.toString(),
      'heureFin': heureFin.toString(),
      'dose': dose,
    };
  }
}
