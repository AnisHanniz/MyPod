import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

class ListeProfilsBasaux extends StatefulWidget {
  const ListeProfilsBasaux({super.key});

  @override
  _ListeProfilsBasauxState createState() => _ListeProfilsBasauxState();
}

class _ListeProfilsBasauxState extends State<ListeProfilsBasaux> {
  List<BasalProfile> profiles = [];
  BasalProfile? activeProfile;

  @override
  void initState() {
    super.initState();
    loadBasalProfiles();
    print(profiles);
  }

  void _showSnackbar(String message) {
    final snackBar = SnackBar(content: Text(message));
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  Future<void> _deleteBasalProfile(BasalProfile profile) async {
    Directory? appDocDir = await getApplicationDocumentsDirectory();
    String profilesDirPath = '${appDocDir.path}/basal_profiles';
    Directory profilesDir = Directory(profilesDirPath);

    if (await profilesDir.exists()) {
      String profileFileName = '${profile.name.replaceAll(' ', '_')}.txt';
      String profileFilePath = '${profilesDir.path}/$profileFileName';
      File profileFile = File(profileFilePath);

      if (await profileFile.exists()) {
        await profileFile.delete();
        _showSnackbar('Profil supprimé: ${profile.name}');
        if (activeProfile == profile) {
          setState(() {
            activeProfile = null;
          });
        }
        await loadBasalProfiles();
      } else {
        _showSnackbar('Profil non trouvé: ${profile.name}');
      }
    } else {
      _showSnackbar('Répertoire des profils basaux non trouvé.');
    }
  }

  Future<void> loadBasalProfiles() async {
    Directory? appDocDir = await getApplicationDocumentsDirectory();
    String profilesDirPath = '${appDocDir.path}/basal_profiles';
    Directory profilesDir = Directory(profilesDirPath);
    print(profilesDir);

    if (await profilesDir.exists()) {
      List<FileSystemEntity> files = profilesDir.listSync();
      List<BasalProfile> profiles = [];
      for (var file in files) {
        if (file is File) {
          List<String> lines = await file.readAsLines();
          String name = lines[0].split(': ')[1];
          double duration = double.parse(lines[1].split(': ')[1].split(' ')[0]);
          double basalRate =
              double.parse(lines[2].split(': ')[1].split(' ')[0]);
          profiles.add(BasalProfile(name, duration, basalRate));
        }
        print(profiles);
      }
      setState(() {
        this.profiles = profiles;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context, listen: false);

    return Scaffold(
      body: profiles.isEmpty
          ? _buildEmptyState()
          : Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 100),
                const Text(
                  'Liste des Profils Basaux',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                const Icon(Icons.list, size: 64),
                const SizedBox(height: 10),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: profiles.length,
                    itemBuilder: (context, index) {
                      final profile = profiles[index];
                      return Card(
                        elevation: 4,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: ListTile(
                          title: Text(
                            profile.name,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Durée: ${profile.duration} heures',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[700],
                                ),
                              ),
                              Text(
                                'Débit: ${profile.basalRate}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[700],
                                ),
                              ),
                              if (profile == activeProfile)
                                const Text(
                                  'Actif: Oui',
                                  style: TextStyle(color: Colors.green),
                                )
                              else
                                const Text(
                                  'Actif: Non',
                                  style: TextStyle(color: Colors.red),
                                ),
                            ],
                          ),
                          trailing: DropdownButton<String>(
                            value:
                                profile == activeProfile ? 'Actif' : 'Inactif',
                            onChanged: (String? newValue) {
                              setState(() {
                                if (newValue == 'Actif') {
                                  activeProfile = profile;
                                  appState.basalEnCours = profile.basalRate;
                                  appState.isTempBasalActive = true;
                                } else if (newValue == 'Inactif') {
                                  activeProfile = null;
                                  appState.fetchSchemaBasalEnCours();
                                  appState.isTempBasalActive = false;
                                }
                                if (newValue == 'Supprimer') {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        title: const Text("Confirmation"),
                                        content: const Text(
                                            "Êtes-vous sûr de vouloir supprimer ce profil basal ?"),
                                        actions: [
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context)
                                                  .pop(); // Fermer le dialogue
                                            },
                                            child: const Text("Annuler"),
                                          ),
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context)
                                                  .pop(); // Fermer le dialogue
                                              _deleteBasalProfile(
                                                  profile); // Supprimer le profil basal
                                            },
                                            child: const Text("Confirmer"),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                }
                              });
                            },
                            items: <String>['Actif', 'Inactif', 'Supprimer']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                          onTap: () {
                            Navigator.pop(context);
                          },
                        ),
                      );
                    },
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    loadBasalProfiles(); // Rafraîchir la liste de profils
                  },
                  child: const Text('Rafraîchir'),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('Fermer'),
                ),
              ],
            ),
      bottomNavigationBar: activeProfile != null
          ? BottomAppBar(
              child: Container(
                height: 48,
                alignment: Alignment.center,
                child: Text(
                  'Profil Actif: ${activeProfile!.name}, Durée Restante: ${activeProfile!.duration} heures',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 20),
          const Icon(Icons.list, size: 64),
          const SizedBox(height: 20),
          const Text(
            'Liste des Profils Basaux',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              loadBasalProfiles(); // Rafraîchir la liste de profils
            },
            child: const Text('Rafraîchir'),
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('Fermer'),
          ),
        ],
      ),
    );
  }
}
