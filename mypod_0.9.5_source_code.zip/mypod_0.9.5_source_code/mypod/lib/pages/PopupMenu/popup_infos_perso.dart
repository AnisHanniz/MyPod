import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mypod/pages/bdd/database.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:provider/provider.dart';

class InfosPerso extends StatefulWidget {
  const InfosPerso({super.key});

  @override
  _InfosPersoState createState() => _InfosPersoState();
}

class _InfosPersoState extends State<InfosPerso> {
  Map<String, dynamic>? _infosPersoData;
  late DatabaseProvider _databaseProvider;

  @override
  void initState() {
    super.initState();
    _databaseProvider = DatabaseProvider();
    _refreshData();
  }

  Future<void> _fetchDataFromAPI(String? mail) async {
    try {
      if (mail != null) {
        final response = await http.get(
          Uri.parse(
            'https://mypodev.000webhostapp.com/API/patient.php?mail=$mail',
          ),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);

          setState(() {
            _infosPersoData = data;
          });
        } else {
          throw Exception('Erreur de communication avec l\'API');
        }
      } else {
        // Gérer le cas où l'mail est null
        print('mail non spécifié');
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
  }

  Future<void> _refreshData() async {
    String? mail = await _databaseProvider.getUserEmail();
    await _fetchDataFromAPI(mail);
  }

  void printInfosActuelles() {
    final appState = Provider.of<AppState>(context, listen: false);
    appState.printInfosActuelles();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 10.0),
              _infosPersoData != null
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const SizedBox(height: 30),
                        const Text(
                          "Informations Personnelles",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 15),
                        _buildInfoCard(
                          'Nom',
                          _infosPersoData!['Nom'] ?? '',
                          Icons.person,
                        ),
                        _buildInfoCard(
                          'Prénom',
                          _infosPersoData!['Prenom'] ?? '',
                          Icons.person,
                        ),
                        _buildInfoCard(
                          'Email Personnel',
                          _infosPersoData!['mail'] ?? '',
                          Icons.email,
                        ),
                        _buildInfoCard(
                          'Date de Naissance',
                          _infosPersoData!['Naissance'] ?? '',
                          Icons.date_range,
                        ),
                        _buildInfoCard(
                          'Adresse',
                          _infosPersoData!['Adresse'] ?? '',
                          Icons.location_on,
                        ),
                        _buildInfoCard(
                          'Numéro de Téléphone',
                          _infosPersoData!['Telephone'] ?? '',
                          Icons.phone,
                        ),
                        _buildInfoCard(
                          'Age',
                          _infosPersoData!['Age'] + " ans" ?? '',
                          Icons.calendar_today,
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text('Fermer'),
                        ),
                      ],
                    )
                  : const Text('Aucune donnée disponible.'),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: FloatingActionButton(
        onPressed: _refreshData,
        tooltip: 'Recharger les données',
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget _buildInfoCard(String title, String data, IconData iconData) {
    return Card(
      child: ListTile(
        leading: Icon(iconData),
        title: Text(title),
        subtitle: Text(data),
      ),
    );
  }
}
