import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mypod/pages/bdd/database.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:provider/provider.dart';

class Historique extends StatefulWidget {
  const Historique({super.key});

  @override
  _HistoriqueState createState() => _HistoriqueState();
}

class _HistoriqueState extends State<Historique> {
  List<Map<String, dynamic>>? _historiqueInjectionsData;
  late DatabaseProvider _databaseProvider;

  @override
  void initState() {
    super.initState();
    _databaseProvider = DatabaseProvider();
    _fetchDataFromDatabase();
  }

  Future<void> _fetchDataFromDatabase() async {
    final db = await _databaseProvider.initDB();
    final historiqueInjections = await db.query('historique_injections_bolus');
    setState(() {
      _historiqueInjectionsData =
          historiqueInjections.isNotEmpty ? historiqueInjections : [];
    });
  }

  Future<void> _transferToDoctor() async {
    final appState = Provider.of<AppState>(context, listen: false);
    int? userId = appState.id;

    if (_historiqueInjectionsData != null &&
        _historiqueInjectionsData!.isNotEmpty) {
      final List<Map<String, dynamic>> dataToSend = [];

      for (final entry in _historiqueInjectionsData!) {
        final formattedDate = _formatDate(entry['date_injection']);

        // Création de la structure JSON pour chaque entrée
        final Map<String, dynamic> rowData = {
          'PatientID': userId.toString(),
          'TempsInjection': entry['heure_injection'],
          'DateInjection': formattedDate,
          'Dose': entry['dose'].toString(),
        };
        dataToSend.add(rowData);
        print(dataToSend);
      }

      // Construction de l'URL avec les données à envoyer
      final apiUrl =
          'https://mypodev.000webhostapp.com/API/historique/bolus.php?${_encodeData(dataToSend)}';

      try {
        final http.Response response = await http.get(
          Uri.parse(apiUrl),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
        );
        print(apiUrl);
        print(response.body);
        print(response.statusCode);

        if (response.statusCode == 200) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Historique transféré avec succès au médecin'),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Erreur lors du transfert de l\'historique'),
            ),
          );
        }
      } catch (error) {
        print('Error transferring data: $error');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
                'Erreur lors du transfert de l\'historique. Veuillez réessayer.'),
          ),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Aucune donnée d\'historique disponible à transférer'),
        ),
      );
    }
  }

  String _encodeData(List<Map<String, dynamic>> dataToSend) {
    // Convertir chaque entrée en format clé-valeur
    final List<String> encodedData = dataToSend.map((entry) {
      final timeParts = entry['TempsInjection'].split(':');
      final hour = int.parse(timeParts[0]);
      final minute = int.parse(timeParts[1]);

      return 'PatientID=${Uri.encodeComponent(entry['PatientID'].toString())}&'
          'TempsInjectionHour=${Uri.encodeComponent(hour.toString())}&'
          'TempsInjectionMinute=${Uri.encodeComponent(minute.toString())}&'
          'DateInjection=${Uri.encodeComponent(entry['DateInjection'])}&'
          'Dose=${Uri.encodeComponent(entry['Dose'].toString())}';
    }).toList();

    // Joindre les données avec "&" pour les séparer dans l'URL
    return encodedData.join('&');
  }

  String _formatDate(String dateString) {
    final dateParts = dateString.split(RegExp(r'[-T]'));
    return '${dateParts[2]}-${dateParts[1]}-${dateParts[0]}';
  }

  Widget _buildTable(String title, List<Map<String, dynamic>>? data) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          if (data != null && data.isNotEmpty)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: DataTable(
                  columnSpacing: 20,
                  dataRowHeight: 60,
                  headingRowHeight: 40,
                  columns: const [
                    DataColumn(label: Text('Date Injection')),
                    DataColumn(label: Text('Heure Injection')),
                    DataColumn(label: Text('Dose')),
                  ],
                  rows: data
                      .map(
                        (row) => DataRow(
                          cells: [
                            DataCell(Text(row['dose']?.toString() ?? '')),
                            DataCell(
                                Text(row['heure_injection']?.toString() ?? '')),
                            DataCell(Text(row['dose']?.toString() ?? '')),
                          ],
                        ),
                      )
                      .toList(),
                ),
              ),
            ),
          if (data == null || data.isEmpty)
            const Text('Aucune donnée disponible.'),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(10.0),
          margin: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 60),
              const Text(
                'Historique des injections',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const Icon(Icons.history),
              const SizedBox(height: 10),
              _buildTable(
                '',
                _historiqueInjectionsData,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _transferToDoctor,
                child: const Text('Transférer au médecin'),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Fermer'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class InjectionPage extends StatefulWidget {
  const InjectionPage({super.key}); // Correction de la syntaxe

  @override
  _InjectionPageState createState() => _InjectionPageState();
}

class _InjectionPageState extends State<InjectionPage> {
  List<Map<String, dynamic>>? _historiqueInjectionsData;
  late DatabaseProvider _databaseProvider;
  bool _dataLoaded = false;

  @override
  void initState() {
    super.initState();
    _databaseProvider = DatabaseProvider();
    _fetchDataFromDatabase();
  }

  Future<void> _fetchDataFromDatabase() async {
    final db = await _databaseProvider.initDB();
    final historiqueInjections = await db.query('historique_injections_bolus');
    setState(() {
      _historiqueInjectionsData =
          historiqueInjections.isNotEmpty ? historiqueInjections : [];
      print(_historiqueInjectionsData);
      _dataLoaded = true;
    });
  }

  String _formatDate(String dateString) {
    final parts = dateString.split('-');
    final year = int.parse(parts[0]);
    final month = int.parse(parts[1]);
    final day = int.parse(parts[2]);
    return '$day/$month/$year';
  }

  Future<void> sendInjections() async {
    if (!_dataLoaded || _historiqueInjectionsData == null) {
      print("dataLoaded :$_dataLoaded");
      return;
    }
    const String apiUrl =
        'https://mypodev.000webhostapp.com/API/historique/bolus.php';

    final appState = Provider.of<AppState>(context, listen: false);
    final userId = appState.id;

    for (final entry in _historiqueInjectionsData!) {
      final formattedDate = _formatDate(entry['date_injection']);

      final Map<String, dynamic> dataToSend = {
        'PatientID': userId.toString(),
        'TempsInjection': entry['heure_injection'],
        'DateInjection': formattedDate,
        'Dose': entry['dose'].toString(),
      };

      final response = await http.post(
        Uri.parse(apiUrl),
        body: jsonEncode(dataToSend),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      print(response.statusCode);
      print(response.body);

      if (response.statusCode == 201) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Success'),
            content: const Text('Injection recorded successfully'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
      } else if (response.statusCode == 409) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Error'),
            content: const Text('Duplicate entry detected'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
      } else {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Error'),
            content: const Text('Failed to record injection'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Injection Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {
                sendInjections();
              },
              child: const Text('Transfer Injections'),
            ),
            Expanded(
              child: _historiqueInjectionsData != null
                  ? ListView.builder(
                      itemCount: _historiqueInjectionsData!.length,
                      itemBuilder: (context, index) {
                        final entry = _historiqueInjectionsData![index];
                        final formattedDate =
                            _formatDate(entry['date_injection']);
                        return ListTile(
                          title: Text('Date: $formattedDate'),
                          subtitle: Text(
                              'Heure: ${entry['heure_injection']}, Dose: ${entry['dose']}'),
                        );
                      },
                    )
                  : const SizedBox(), // Affiche une boîte vide si les données ne sont pas chargées
            ),
          ],
        ),
      ),
    );
  }
}
