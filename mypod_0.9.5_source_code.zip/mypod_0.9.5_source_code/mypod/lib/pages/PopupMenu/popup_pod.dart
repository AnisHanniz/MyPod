import 'package:flutter/material.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:mypod/utils/app_constants.dart';
import 'package:provider/provider.dart';

class PodPage extends StatefulWidget {
  const PodPage({super.key});

  @override
  _PodPageState createState() => _PodPageState();
}

class _PodPageState extends State<PodPage> {
  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    bool isConnected = appState.isConnectedToPump;
    double insulinRemaining = appState.insulinRemaining;
    double podLifetimeRemaining = appState.podLifetime;

    return AlertDialog(
      title: const Text(
        'État du Pod',
        textAlign: TextAlign.center,
      ),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isConnected ? Icons.check_circle : Icons.error,
              color: isConnected ? AppConstants.violet : Colors.red,
              size: 64.0,
            ),
            const SizedBox(height: 20.0),
            Text(
              isConnected ? 'Connecté' : 'Déconnecté',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 24.0,
                color: isConnected ? AppConstants.violet : Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20.0),
            _buildInfoRow(
              'Quantité d\'insuline restante:\n',
              '$insulinRemaining unités',
            ),
            const SizedBox(height: 10.0),
            _buildInfoRow(
              'Durée de vie restante du pod:\n',
              '$podLifetimeRemaining jours',
            ),
          ],
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Fermer'),
        ),
        if (isConnected)
          ElevatedButton(
            onPressed: () {
              AppStateBluetooth.allBluetooth.closeConnection();
              appState.isConnectedToPump = false;
            },
            child: const Text('Se déconnecter du Pod'),
          ),
      ],
    );
  }

  Widget _buildInfoRow(String title, String value) {
    return Column(
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 10.0), // Ajout d'un espace entre les lignes
        Text(
          value,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 16.0),
        ),
      ],
    );
  }
}
