import 'package:flutter/material.dart';
import 'package:mypod/pages/bdd/database.dart';
import 'package:mypod/utils/app_constants.dart';
import 'package:mypod/utils/app_routes.dart';

class SettingsPopup extends StatefulWidget {
  const SettingsPopup({super.key});

  @override
  _SettingsPopupState createState() => _SettingsPopupState();
}

class _SettingsPopupState extends State<SettingsPopup> {
  int selectedBolusOption = 10;
  double currentSliderValue = 0.4;
  bool valuesChanged = false;

  // Initialisez votre fournisseur de base de données
  late DatabaseProvider _databaseProvider;

  @override
  void initState() {
    super.initState();
    _databaseProvider = DatabaseProvider();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: AlertDialog(
        contentPadding: const EdgeInsets.all(20.0),
        title: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.settings),
            SizedBox(width: 5.0),
            Text(
              'Réglages',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildResetPasswordButton(),
              const SizedBox(height: 15),
              _buildSetMaxBolusDoseComboBox(),
              const SizedBox(height: 10),
              _buildSetInjectionSpeedSlider(),
            ],
          ),
        ),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () {
                  _showSaveChangesDialog();
                },
                child: const Text('Confirmer'),
              ),
              const SizedBox(width: 20),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Annuler'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showSaveChangesDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Enregistrer les changements ?'),
          content: const Text('Voulez-vous enregistrer les changements ?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Non'),
            ),
            TextButton(
              onPressed: () {
                _saveChanges();
                Navigator.of(context).pop();
              },
              child: const Text('Oui'),
            ),
          ],
        );
      },
    );
  }

  void _saveChanges() async {
    try {
      //final db = await _databaseProvider.initDB();
      await _databaseProvider.insertOrUpdateUtilisateurParams(
        await _databaseProvider.getUserId() ?? 0,
        await _databaseProvider.getUserEmail() ?? '',
        await _databaseProvider.getUserToken() ?? '',
        currentSliderValue,
      );

      // Afficher un snackbar pour indiquer que les changements ont été enregistrés avec succès
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Changements enregistrés avec succès.'),
          duration: Duration(seconds: 2),
        ),
      );

      print(
          'Changements enregistrés: Dose maximale de bolus: $selectedBolusOption, Vitesse d\'injection: $currentSliderValue');
    } catch (e) {
      // En cas d'erreur, afficher un snackbar avec le message d'erreur
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content:
              Text('Erreur lors de l\'enregistrement des changements : $e'),
          duration: const Duration(seconds: 2),
        ),
      );
      print('Erreur lors de l\'enregistrement des changements : $e');
    }
  }

  Widget _buildResetPasswordButton() {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, AppRoutes.forgotPasswordScreen);
      },
      child: RichText(
        text: TextSpan(
          children: [
            const TextSpan(
              text: "Mot de passe oublié? ",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 14,
                color: Colors.black,
              ),
            ),
            TextSpan(
              text: "Réinitialiser",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: AppConstants.violet,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSetMaxBolusDoseComboBox() {
    List<int> bolusOptions = [10, 20, 30, 40, 50];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Dose maximale de bolus:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        DropdownButton<int>(
          value: selectedBolusOption,
          onChanged: (int? newValue) {
            if (newValue != null) {
              setState(() {
                selectedBolusOption = newValue;
                valuesChanged = true;
              });
            }
          },
          items: bolusOptions.map((int value) {
            return DropdownMenuItem<int>(
              value: value,
              child: Text('$value'),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSetInjectionSpeedSlider() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Vitesse d\'injection:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Slider(
          value: currentSliderValue,
          min: 0,
          max: 1,
          divisions: 20,
          label: currentSliderValue.toStringAsFixed(2),
          onChanged: (double value) {
            setState(() {
              currentSliderValue = value;
              valuesChanged = true;
            });
          },
        ),
      ],
    );
  }
}
