import 'dart:async';

import 'package:flutter/material.dart';
import 'package:mypod/utils/AppState.dart';
import 'package:provider/provider.dart';

class PopupRappels {
  static late AppState _appState;
  static late BuildContext _context;
  static late Timer _notificationTimer;

  static void initialize(BuildContext context) {
    _context = context;
    _appState = Provider.of<AppState>(_context, listen: false);
    _startNotificationThreads(
        const Duration(minutes: 1)); // Démarrer avec une minute par défaut
  }

  static void _startNotificationThreads(Duration duration) {
    _notificationTimer = Timer.periodic(duration, (timer) {
      _checkInsulinRemaining();
    });
  }

  static void _checkInsulinRemaining() {
    if (_appState.insulinRemaining < _appState.insulinNotificationThreshold) {
      _showInsulinRemainingNotification();
    }
  }

  static void _showInsulinRemainingNotification() {
    showDialog(
      context: _context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Attention'),
          content: Text(
              'Le réservoir de votre pompe à insuline est à ${_appState.insulinRemaining} u. Pensez à bientôt le recharger.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  static void updateNotificationFrequency(Duration duration) {
    _notificationTimer.cancel(); // Annuler le minuteur existant
    if (duration.inSeconds > 0) {
      // Redémarrer le minuteur si la fréquence est supérieure à zéro
      _startNotificationThreads(duration);
    } else {
      _startNotificationThreads(const Duration(hours: 99));
    }
  }

  static void updateNotificationThreshold(double value) {
    _appState.insulinNotificationThreshold = value;
  }
}

class NotificationSettingsPage extends StatefulWidget {
  const NotificationSettingsPage({super.key});

  @override
  _NotificationSettingsPageState createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage> {
  int _selectedValue = 1;

  @override
  Widget build(BuildContext context) {
    return _buildNotificationOptionsDialog(context);
  }

  Widget _buildNotificationOptionsDialog(BuildContext context) {
    return AlertDialog(
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Row(
            children: [
              Center(
                child: Text(
                  'Fréquence des rappels',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
              ),
              SizedBox(width: 5.0),
              Icon(Icons.notification_add),
            ],
          ),
          const SizedBox(height: 20.0),
          _buildNotificationOption(
            title: 'Jamais',
            value: 0, // Nouvelle valeur pour "jamais"
          ),
          _buildNotificationOption(
            title: 'Toutes les 30 secondes',
            value: 30,
          ),
          _buildNotificationOption(
            title: 'Toutes les 1 minute',
            value: 60,
          ),
          _buildNotificationOption(
            title: 'Toutes les 5 minutes',
            value: 300,
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Fermer'),
        ),
      ],
    );
  }

  Widget _buildNotificationOption({
    required String title,
    required int value,
  }) {
    return RadioListTile<int>(
      title: Text(title),
      value: value,
      groupValue: _selectedValue,
      onChanged: (int? newValue) {
        if (newValue != null) {
          setState(() {
            _selectedValue = newValue;
          });
          if (newValue == 0) {
            PopupRappels.updateNotificationFrequency(
                const Duration(seconds: 0));
          } else {
            PopupRappels.updateNotificationFrequency(
                Duration(seconds: newValue));
          }
        }
      },
    );
  }
}
