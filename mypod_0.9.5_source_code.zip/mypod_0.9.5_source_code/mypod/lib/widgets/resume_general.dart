import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mypod/utils/AppState.dart';

class ResumeGeneralCard extends StatefulWidget {
  final AppState? appState;

  const ResumeGeneralCard({super.key, this.appState});

  @override
  _ResumeGeneralCardState createState() => _ResumeGeneralCardState();
}

class _ResumeGeneralCardState extends State<ResumeGeneralCard> {
  DateTime dateChangementPod = DateTime.now();
  DateTime dateTransBolus = DateTime.now();

  @override
  void initState() {
    super.initState();
    widget.appState?.addListener(_onAppStateChange);
    _updateBasalRate();
  }

  @override
  void dispose() {
    widget.appState?.removeListener(_onAppStateChange);
    super.dispose();
  }

  void _onAppStateChange() {
    setState(() {});
  }

  Future<void> _updateBasalRate() async {
    await widget.appState?.fetchSchemaBasalEnCours();
  }

  @override
  Widget build(BuildContext context) {
    final currentBasalRate = widget.appState?.basalEnCours ?? 0.0;
    return Card(
      color: Colors.transparent,
      elevation: 0,
      margin: const EdgeInsets.all(5),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildInfoRow(context, 'Basal en cours:', '$currentBasalRate u/h',
                  Icons.trending_down),
              _buildInfoRow(
                  context,
                  'Pod remplacé le:',
                  DateFormat('dd-MM-yyyy').format(dateChangementPod),
                  Icons.event),
              _buildInfoRow(
                  context,
                  'Transmission Historique',
                  DateFormat('dd-MM-yyyy').format(dateTransBolus),
                  Icons.update),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(
      BuildContext context, String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: Colors.black),
          const SizedBox(width: 8),
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
          const Spacer(),
          Text(
            value,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
