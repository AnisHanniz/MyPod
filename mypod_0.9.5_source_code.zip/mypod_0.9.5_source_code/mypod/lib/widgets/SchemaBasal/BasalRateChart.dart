import 'dart:convert';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mypod/utils/AppState.dart';
import 'package:provider/provider.dart';

class BasalRateChart extends StatelessWidget {
  const BasalRateChart({super.key});

  Future<List<FlSpot>> _fetchSchemaBasalAndGenerateSpots(String id) async {
    try {
      final List<DataPoint> dataPoints = await _fetchSchemaBasal(id);
      return generateSpotsFromDataPoints(dataPoints);
    } catch (e) {
      // Gérer les erreurs de récupération des données
      print('Error fetching schema basal: $e');
      return [];
    }
  }

  Future<List<DataPoint>> _fetchSchemaBasal(String id) async {
    const url =
        'https://mypodev.000webhostapp.com/API/schema_basaux/schema.php';
    final response = await http.post(Uri.parse(url), body: {
      'id': id,
    });

    if (response.statusCode == 200) {
      final responseData = jsonDecode(response.body);
      print(responseData);
      return _parseSchemaBasal(responseData);
    } else {
      throw Exception('Failed to load schema basal');
    }
  }

  List<DataPoint> _parseSchemaBasal(dynamic data) {
    List<DataPoint> points = [];
    for (var item in data) {
      try {
        List<String> heureDebutParts =
            (item['horaire_debut'] ?? '00:00:00').split(':');
        List<String> heureFinParts =
            (item['horaire_fin'] ?? '00:00:00').split(':');

        TimeOfDay heureDebut = TimeOfDay(
          hour: int.parse(heureDebutParts[0]),
          minute: int.parse(heureDebutParts[1]),
        );

        TimeOfDay heureFin = TimeOfDay(
          hour: int.parse(heureFinParts[0]),
          minute: int.parse(heureFinParts[1]),
        );

        double dose = double.tryParse(item['dose'] ?? '0') ?? 0;
        points.add(DataPoint(heureDebut, heureFin, dose));
      } catch (e) {
        print('Error parsing data: $e');
      }
    }
    return points;
  }

  List<FlSpot> generateSpotsFromDataPoints(List<DataPoint> dataPoints) {
    List<FlSpot> spots = [];
    for (int i = 0; i < dataPoints.length; i++) {
      if (i == dataPoints.length - 1) {
        // Si c'est le dernier élément, ajoutez minuit comme 24
        spots.add(FlSpot(
            dataPoints[i].heureDebut.hour.toDouble(), dataPoints[i].dose));
        spots.add(FlSpot(24, dataPoints[i].dose));
      } else {
        spots.add(FlSpot(
            dataPoints[i].heureDebut.hour.toDouble(), dataPoints[i].dose));
        spots.add(
            FlSpot(dataPoints[i].heureFin.hour.toDouble(), dataPoints[i].dose));
      }
    }
    print(spots);
    return spots;
  }

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Expanded(
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
            child: Text(
              'Profil Basal Actuel',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 5), // Espace sous le titre
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: FutureBuilder<List<FlSpot>>(
                future:
                    _fetchSchemaBasalAndGenerateSpots(appState.id.toString()),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else if (snapshot.hasData) {
                    return buildLineChart(snapshot.data!);
                  } else {
                    return const SizedBox.shrink();
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildLineChart(List<FlSpot> spots) {
    return LineChart(
      LineChartData(
        gridData: FlGridData(
          show: true,
          drawVerticalLine: true,
          drawHorizontalLine: true,
          horizontalInterval: 1,
          getDrawingHorizontalLine: (value) => FlLine(
            color: const Color.fromARGB(255, 61, 69, 75),
            strokeWidth: 2,
          ),
        ),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: SideTitles(
            showTitles: true,
            getTextStyles: (_, __) => const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 9,
            ),
            interval: 4, // Afficher une étiquette pour chaque heure
            getTitles: (value) {
              return '${value.toInt()}h';
            },
          ),
          leftTitles: SideTitles(
            showTitles: true,
            getTextStyles: (_, __) => const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 9,
            ),
            getTitles: (value) {
              return '${value.toStringAsFixed(2)}U';
            },
          ),
        ),
        borderData: FlBorderData(show: true),
        minX: 0,
        maxX: 24,
        minY: 0,
        maxY: 1,
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: false,
            colors: [Colors.white],
            barWidth: 2,
            isStrokeCapRound: true,
            dotData: FlDotData(show: false),
            belowBarData: BarAreaData(show: true),
          ),
        ],
      ),
    );
  }
}

class DataPoint {
  final TimeOfDay heureDebut;
  final TimeOfDay heureFin;
  final double dose;

  DataPoint(this.heureDebut, this.heureFin, this.dose);
}
