import 'dart:convert';

import 'package:all_bluetooth/all_bluetooth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mypod/main.dart';
import 'package:mypod/pages/PopupMenu/Sch%C3%A9masBasaux/popup_basaux.dart';
import 'package:mypod/pages/bluetooth/all_bluetooth.dart';
import 'package:mypod/pages/bluetooth/all_bluetooth_chat.dart';
import 'package:provider/provider.dart';

class AppState extends ChangeNotifier {
  double _insulinRemaining = 200;
  double _podLifetime = 2.5;
  bool _isConnectedToPump = false;
  String? _token;
  String? _mail;
  int? _id;
  double _basalEnCours = 0.0;
  double _insulinNotificationThreshold = 50;
  bool isTempBasalActive = false;

  AppState() {
    _isConnectedToPump = false;
    _mail = '';
    init();
  }

  List<DataPoint> _parseSchemaBasal(dynamic data) {
    List<DataPoint> points = [];
    for (var item in data) {
      List<String> heureDebutParts =
          (item['horaire_debut'] ?? '00:00:00').split(':');
      List<String> heureFinParts =
          (item['horaire_fin'] ?? '00:00:00').split(':');

      TimeOfDay heureDebut = TimeOfDay(
        hour: int.parse(heureDebutParts[0]),
        minute: int.parse(heureDebutParts[1]),
      );

      TimeOfDay heureFin = TimeOfDay(
        hour: int.parse(heureFinParts[0]),
        minute: int.parse(heureFinParts[1]),
      );

      double dose = double.tryParse(item['dose'] ?? '0') ?? 0;
      points.add(DataPoint(heureDebut, heureFin, dose));
    }
    return points;
  }

  Future<void> fetchSchemaBasalEnCours() async {
    try {
      final response = await http.post(
        Uri.parse(
            'https://mypodev.000webhostapp.com/API/schema_basaux/schema.php'),
        body: {'id': _id.toString()}, // Utiliser _id au lieu de id
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final schemaBasal = _parseSchemaBasal(responseData);
        final now = TimeOfDay.now();
        for (final dataPoint in schemaBasal) {
          final heureDebut = dataPoint.heureDebut;
          final heureFin = dataPoint.heureFin;

          if (heureDebut.hour < now.hour ||
              (heureDebut.hour == now.hour &&
                  heureDebut.minute <= now.minute)) {
            if (heureFin.hour > now.hour ||
                (heureFin.hour == now.hour && heureFin.minute > now.minute)) {
              _basalEnCours = dataPoint.dose;
              break;
            }
          }
        }
        notifyListeners();
      } else {
        throw Exception('Failed to load schema basal');
      }
    } catch (e) {
      print('Error fetching schema basal: $e');
    }
  }

  void printInfosActuelles() {
    print("\nInfos Actuelles :\n"
        "token: $_token\n"
        "insulinRemaining: $_insulinRemaining\n"
        "podLifetime: $_podLifetime\n"
        "isConnectedToPump: $_isConnectedToPump\n"
        "Email: $_mail\n"
        "id: $_id");
  }

  void init() async {
    try {
      final response = await http.get(Uri.parse(
          'https://mypodev.000webhostapp.com/API/patient.php?email=$_mail'));
      if (response.statusCode == 200) {
        final userData = json.decode(response.body);
        _insulinRemaining = double.parse(userData['insulinRemaining']);
        _podLifetime = double.parse(userData['podLifetime']);
        _id = int.parse(userData['PatientID']);
        _token = userData['token'];
        fetchSchemaBasalEnCours();
        notifyListeners();
      } else {
        throw Exception('Failed to load user data');
      }
    } catch (e) {
      print('Error fetching user data: $e');
    }
  }

  void updateInsulinRemaining(double targetRemaining) {
    _insulinRemaining = targetRemaining;
    notifyListeners();
  }

  void updateConnectionStatus(bool isConnected) {
    if (_isConnectedToPump != isConnected) {
      _isConnectedToPump = isConnected;
      notifyListeners();
    }
  }

  double get insulinRemaining => _insulinRemaining;
  set insulinRemaining(double value) {
    _insulinRemaining = value;
    notifyListeners();
  }

  double get podLifetime => _podLifetime;
  set podLifetime(double value) {
    _podLifetime = value;
    notifyListeners();
  }

  String? get token => _token;
  set token(String? value) {
    _token = value;
    notifyListeners();
  }

  bool get isConnectedToPump => _isConnectedToPump;
  set isConnectedToPump(bool value) {
    _isConnectedToPump = value;
    notifyListeners();
  }

  int? get id => _id; // Utiliser _id au lieu de id
  set id(int? value) {
    _id = value; // Utiliser _id au lieu de id
    notifyListeners();
  }

  String? get mail => _mail;
  set mail(String? value) {
    _mail = value;
    notifyListeners();
  }

  double get basalEnCours => _basalEnCours;
  set basalEnCours(double value) {
    _basalEnCours = value;
    notifyListeners();
  }

  double get insulinNotificationThreshold => _insulinNotificationThreshold;
  set insulinNotificationThreshold(double value) {
    _insulinNotificationThreshold = value;
    notifyListeners();
  }
}

class BasalProfile {
  final String name;
  final double duration;
  final double basalRate;

  BasalProfile(this.name, this.duration, this.basalRate);
}

class AppStateBluetooth extends StatelessWidget {
  const AppStateBluetooth({super.key});

  static dynamic _allBluetooth = AllBluetooth();

  // Setter pour _allBluetooth
  static set allBluetooth(AllBluetooth value) {
    _allBluetooth = value;
  }

  static bool get isConnectedToPump =>
      Provider.of<AppState>(navigatorKey.currentContext!, listen: false)
          .isConnectedToPump;
  static set isConnectedToPump(bool value) {
    Provider.of<AppState>(navigatorKey.currentContext!, listen: false)
        .isConnectedToPump = value;
  }

  static AllBluetooth get allBluetooth => _allBluetooth;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: StreamBuilder(
          stream: allBluetooth.listenForConnection,
          builder: (context, snapshot) {
            final result = snapshot.data;
            print(result);

            if (result?.state == true) {
              AppState appState = Provider.of<AppState>(context);
              appState._isConnectedToPump = true;
              //Navigator.of(context).pop();
              //return const HomePage();
              return const ChatScreen();
            }
            print(result);
            //return const AccueilBluetooth();
            return const AccueilBluetooth();
          }),
      theme: ThemeData(
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}
