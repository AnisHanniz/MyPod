package com.example.podapp

import android.bluetooth.*
import android.content.Context
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.IOException
import java.util.*

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.example.podapp/bluetooth"
    private val APP_NAME = "PodApp"
    private val MY_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var acceptThread: AcceptThread? = null
    private var serverSocket: BluetoothServerSocket? = null
    private val connectedSockets: MutableList<BluetoothSocket> = mutableListOf()

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "startServer" -> {
                    val success = startBluetoothServer()
                    if (success) {
                        result.success("Server Started")
                    } else {
                        result.error("ERROR", "Failed to start Bluetooth server", null)
                    }
                }
                "stopServer" -> {
                    stopBluetoothServer(result)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }

    private fun startBluetoothServer(): Boolean {
        val bluetoothManager: BluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            return false
        }

        acceptThread = AcceptThread(bluetoothAdapter).also {
            it.start()
        }

        return true
    }

    private fun stopBluetoothServer(result: MethodChannel.Result) {
        try {
            acceptThread?.cancel()
            acceptThread = null
            synchronized(connectedSockets) {
                connectedSockets.forEach { socket ->
                    try {
                        socket.close()
                    } catch (e: IOException) {
                        // Handle exception for each socket
                    }
                }
                connectedSockets.clear()
            }
            result.success("Server stopped successfully")
        } catch (e: IOException) {
            result.error("ERROR_STOPPING_SERVER", "Failed to stop the Bluetooth server: ${e.message}", null)
        }
    }

    private inner class AcceptThread(private val bluetoothAdapter: BluetoothAdapter) : Thread() {
        private val serverSocket: BluetoothServerSocket? by lazy(LazyThreadSafetyMode.NONE) {
            bluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(APP_NAME, MY_UUID)
        }
    
        override fun run() {
            // Keep listening until exception occurs or a socket is returned
            var shouldLoop = true
            while (shouldLoop) {
                val socket: BluetoothSocket? = try {
                    serverSocket?.accept()
                } catch (e: IOException) {
                    shouldLoop = false
                    null
                }
    
                socket?.also {
                    // A connection was accepted. Perform work associated with
                    // the connection in a separate thread.
                    manageConnectedSocket(it)
                    serverSocket?.close()
                    shouldLoop = false
                }
            }
        }
    
        fun cancel() {
            try {
                serverSocket?.close()
            } catch (e: IOException) {
            }
        }
    }
    
    private fun manageConnectedSocket(socket: BluetoothSocket) {
        // Handle the connection in a separate thread or service
        // You might want to pass the socket to another thread to perform
        // I/O operations like reading and writing
    }
}