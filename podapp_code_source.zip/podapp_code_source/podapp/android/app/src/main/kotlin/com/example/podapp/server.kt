package com.example.podapp

import android.app.Service
import android.bluetooth.*
import android.content.Intent
import android.os.IBinder
import java.util.UUID
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseCallback
import java.nio.ByteBuffer 

class BluetoothLeService : Service() {
    private lateinit var bluetoothManager: BluetoothManager
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var gattServer: BluetoothGattServer? = null

    // Declare insulinRemainingCharacteristic as a class property
    private lateinit var insulinRemainingCharacteristic: BluetoothGattCharacteristic

    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("33cc5e8f-70cb-42ce-8735-e66069152830")
        val CHARACTERISTIC_INSULIN_REMAINING_UUID: UUID = UUID.fromString("be25802a-a0b1-4387-91ad-7734702b0ede")
        val CHARACTERISTIC_BOLUS_UUID: UUID = UUID.fromString("b07218d2-42d5-420e-b593-e16d576f32aa")
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        initialize()
        startAdvertising()
        setupServer()
    }

    private fun initialize() {
        bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
    }

    private fun startAdvertising() {
        val advertiser = bluetoothAdapter.bluetoothLeAdvertiser ?: return
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_POWER)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(true)
            .build()

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(true)
            .build()

        advertiser.startAdvertising(settings, data, advertiseCallback)
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
            super.onStartSuccess(settingsInEffect)
            // Successfully started advertising
        }

        override fun onStartFailure(errorCode: Int) {
            super.onStartFailure(errorCode)
            // Handle failure
        }
    }

    private fun setupServer() {
        gattServer = bluetoothManager.openGattServer(this, gattServerCallback) ?: return

        val service = BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)

        // Initialize insulinRemainingCharacteristic here
        insulinRemainingCharacteristic = BluetoothGattCharacteristic(
            CHARACTERISTIC_INSULIN_REMAINING_UUID,
            BluetoothGattCharacteristic.PROPERTY_READ or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_READ
        )
        val injectionCharacteristic = BluetoothGattCharacteristic(
            CHARACTERISTIC_BOLUS_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
            )

        service.addCharacteristic(injectionCharacteristic)

        // Set the initial value for the characteristic
        val insulinRemaining: Double = 200.0
        val insulinRemainingBytes = ByteBuffer.allocate(8).putDouble(insulinRemaining).array()
        insulinRemainingCharacteristic.setValue(insulinRemainingBytes)

        service.addCharacteristic(insulinRemainingCharacteristic)
        gattServer?.addService(service)
    }

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        override fun onCharacteristicWriteRequest(device: BluetoothDevice?, requestId: Int, characteristic: BluetoothGattCharacteristic, preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray) {
            super.onCharacteristicWriteRequest(device, requestId, characteristic, preparedWrite, responseNeeded, offset, value)
            
            if (CHARACTERISTIC_BOLUS_UUID == characteristic.uuid) {
                // Convertir les bytes en double (le montant de bolus)
                val bolusAmount = ByteBuffer.wrap(value).double
                
                // Récupérer la valeur actuelle d'insulinRemaining
                val currentInsulinRemainingBytes = insulinRemainingCharacteristic.value
                val currentInsulinRemaining = ByteBuffer.wrap(currentInsulinRemainingBytes).double
                
                // Déduire le montant du bolus de insulinRemaining
                val newInsulinRemaining = currentInsulinRemaining - bolusAmount
                
                // Mettre à jour la valeur d'insulinRemaining
                insulinRemainingCharacteristic.value = ByteBuffer.allocate(8).putDouble(newInsulinRemaining).array()
                
                // Envoyer une réponse au client Bluetooth
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                
                // Mettre à jour la valeur d'insulinRemaining sur les clients abonnés
                gattServer?.notifyCharacteristicChanged(device, insulinRemainingCharacteristic, false)
            }
        }
    }
    

    override fun onDestroy() {
        super.onDestroy()
        gattServer?.close()
    }
}
