import 'package:all_bluetooth/all_bluetooth.dart';
import 'package:flutter/material.dart';
import 'package:podapp/main.dart';
import 'package:podapp/pages/all_bluetooth.dart';
import 'package:podapp/pages/all_bluetooth_chat.dart';
import 'package:provider/provider.dart';

class AppState extends ChangeNotifier {
  double _insulinRemaining = 120;
  double dernierBolus = 10;
  bool _isConnectedToPump = false;
  double _basalEnCours = 0.0;
  double _insulinNotificationThreshold = 50;
  bool isTempBasalActive = false;
  DateTime debutDate = DateTime(2024, 1, 1);
  DateTime expireDate = DateTime(2024, 2, 5);

  List<DataPoint> _schemaBasal = [];

  List<DataPoint> get schemaBasal => _parseSchemaBasal(_schemaBasal);

  AppState() {
    _isConnectedToPump = false;
    _insulinRemaining = 120;
    dernierBolus = 10;
    init();
  }

  int _toMinutes(TimeOfDay time) {
    return time.hour * 60 + time.minute;
  }

  bool _isTimeOfDayBeforeOrAt(TimeOfDay time1, TimeOfDay time2) {
    return _toMinutes(time1) <= _toMinutes(time2);
  }

  double _calculateBasalEnCours() {
    TimeOfDay now = TimeOfDay.now();

    DataPoint? activeProfile;
    for (DataPoint dataPoint in _schemaBasal) {
      if (_isTimeOfDayBeforeOrAt(dataPoint.heureDebut, now) &&
          !_isTimeOfDayBeforeOrAt(dataPoint.heureFin, now)) {
        activeProfile = dataPoint;
        break;
      }
    }

    if (activeProfile == null) return 0.0;

    return activeProfile.dose;
  }

  set schemaBasal(List<DataPoint> value) {
    // Setter pour le schéma basal
    _schemaBasal = value;
    notifyListeners();
  }

  static void updateSchemaBasal(
      BuildContext context, List<DataPoint> schemaBasal) {
    final appState = Provider.of<AppState>(context, listen: false);
    appState.schemaBasal = schemaBasal;
  }

  List<DataPoint> _parseSchemaBasal(dynamic data) {
    List<DataPoint> points = [];
    for (var item in data) {
      List<String> heureDebutParts =
          (item['horaire_debut'] ?? '00:00:00').split(':');
      List<String> heureFinParts =
          (item['horaire_fin'] ?? '00:00:00').split(':');

      TimeOfDay heureDebut = TimeOfDay(
        hour: int.parse(heureDebutParts[0]),
        minute: int.parse(heureDebutParts[1]),
      );

      TimeOfDay heureFin = TimeOfDay(
        hour: int.parse(heureFinParts[0]),
        minute: int.parse(heureFinParts[1]),
      );

      double dose = double.tryParse(item['dose'] ?? '0') ?? 0;
      points.add(DataPoint(heureDebut, heureFin, dose));
    }
    return points;
  }

  void init() async {}

  void updateInsulinRemaining(double targetRemaining) {
    _insulinRemaining = targetRemaining;
    notifyListeners();
  }

  void updateConnectionStatus(bool isConnected) {
    if (_isConnectedToPump != isConnected) {
      _isConnectedToPump = isConnected;
      notifyListeners();
    }
  }

  double get insulinRemaining => _insulinRemaining;
  set insulinRemaining(double value) {
    _insulinRemaining = value;
    notifyListeners();
  }

  bool get isConnectedToPump => _isConnectedToPump;
  set isConnectedToPump(bool value) {
    _isConnectedToPump = value;
    notifyListeners();
  }

  double get basalEnCours => _basalEnCours;
  set basalEnCours(double value) {
    _basalEnCours = value;
    notifyListeners();
  }

  double get insulinNotificationThreshold => _insulinNotificationThreshold;
  set insulinNotificationThreshold(double value) {
    _insulinNotificationThreshold = value;
    notifyListeners();
  }
}

class BasalProfile {
  final String name;
  final double duration;
  final double basalRate;

  BasalProfile(this.name, this.duration, this.basalRate);
}

class AppStateBluetooth extends StatelessWidget {
  const AppStateBluetooth({Key? key}) : super(key: key);

  static dynamic _allBluetooth = AllBluetooth();

  // Setter pour _allBluetooth
  static set allBluetooth(AllBluetooth value) {
    _allBluetooth = value;
  }

  static AllBluetooth get allBluetooth => _allBluetooth;

  static bool get isConnectedToPump =>
      Provider.of<AppState>(navigatorKey.currentContext!, listen: false)
          .isConnectedToPump;
  static set isConnectedToPump(bool value) {
    Provider.of<AppState>(navigatorKey.currentContext!, listen: false)
        .isConnectedToPump = value;
  }

  @override
  Widget build(BuildContext context) {
    AppState appState = Provider.of<AppState>(context, listen: false);
    return MaterialApp(
      home: StreamBuilder(
        stream: allBluetooth.listenForConnection,
        builder: (context, snapshot) {
          final result = snapshot.data;
          print(result);

          if (result?.state == true) {
            print("Connexion réussie, changement vers ChatScreen");
            appState._isConnectedToPump = true;
            //Navigator.of(context).pop();
            //return const HomePage();
            return const ChatScreen();
          }
          print(result);
          //return const AccueilBluetooth();
          return const AccueilBluetooth();
        },
      ),
      theme: ThemeData(
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}
