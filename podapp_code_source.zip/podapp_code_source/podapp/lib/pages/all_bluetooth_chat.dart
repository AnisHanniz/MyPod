import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:podapp/pages/AppState.dart';
import 'package:provider/provider.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final messageController = TextEditingController();
  final messages = <Message>[];

  Timer? _timer;
  @override
  void initState() {
    super.initState();
    final appState = Provider.of<AppState>(context, listen: false);
    appState.isConnectedToPump = true;
    AppStateBluetooth.isConnectedToPump = true;
    // Écouteur pour les données Bluetooth
    AppStateBluetooth.allBluetooth.listenForData.listen(onDataReceived);
    Timer.periodic(const Duration(seconds: 5), (timer) {
      if (!appState.isConnectedToPump) {
        timer.cancel(); // Arrête le timer si isConnectedToPump devient faux
        AppStateBluetooth.allBluetooth.closeConnection();
      } else {
        _startRefreshTimer(); // Exécute la tâche toutes les 5 secondes
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    messageController.dispose();
    AppStateBluetooth.allBluetooth.closeConnection();
    _stopRefreshTimer();
  }

  // Fonction pour démarrer le timer de rafraîchissement
  void _startRefreshTimer() {
    final appState = Provider.of<AppState>(context, listen: false);
    _timer = Timer.periodic(const Duration(seconds: 8), (Timer timer) {
      Timer.periodic(const Duration(seconds: 10), (timer) {
        if (!appState.isConnectedToPump) {
          timer.cancel(); // Arrête le timer si isConnectedToPump devient faux
          _stopRefreshTimer();
        } else {
          sendInsulinRemaining();
          sendLifeTime(context); // Exécute la tâche toutes les 5 secondes
        }
      });
    });
  }

  // Fonction pour arrêter le timer de rafraîchissement
  void _stopRefreshTimer() {
    _timer?.cancel();
  }

  void onDataReceived(dynamic event) {
    String message = event.toString();
    final appState = Provider.of<AppState>(context, listen: false);

    if (isBasalEnCours(message)) {
      print('Message conforme au schéma basal : $message');
      print('Dose basale actuelle : ${appState.basalEnCours}');
    }
    messages.add(Message(
      message: message,
      isMe: false,
    ));
    if (isBolus(message)) {
      print('Message conforme à une commande de bolus : $message');
      print('Bolus en cours de quantité : ${appState.insulinRemaining}');
    }
    messages.add(Message(
      message: message,
      isMe: false,
    ));

    setState(() {});
  }

  bool isBasalEnCours(String message) {
    final appState = Provider.of<AppState>(context, listen: false);
    RegExp regExp = RegExp(r'^basalEnCours: (\d+(\.\d+)?)$');
    Match? match = regExp.firstMatch(message);
    if (match != null) {
      print("basal match");
      String value = match.group(
          1)!; // Obtenez la valeur correspondante sans 'insulinRemaining:'
      print("basal : $value");
      appState.basalEnCours = double.parse(value);
      return true;
    } else {
      return false;
    }
  }

  bool isBolus(String message) {
    final appState = Provider.of<AppState>(context, listen: false);
    RegExp regExp = RegExp(r'^bolus: (\d+(\.\d+)?)$');
    Match? match = regExp.firstMatch(message);
    if (match != null) {
      print("bolus match");
      String value = match.group(
          1)!; // Obtenez la valeur correspondante sans 'insulinRemaining:'
      print("bolus : $value");
      appState.insulinRemaining -= double.parse(value);
      return true;
    } else {
      return false;
    }
  }

  Future<void> sendInsulinRemaining() async {
    try {
      final appState = Provider.of<AppState>(context, listen: false);
      print(appState.insulinRemaining.toString());

      // Convertir la liste en chaîne JSON
      String jsonString = json.encode(appState.insulinRemaining);

      final message = 'inslulinRemaining: $jsonString';
      print(message);
      // Envoyer la chaîne JSON
      AppStateBluetooth.allBluetooth.sendMessage(message);

      messages.add(Message(
        message: message,
        isMe: true,
      ));
      setState(() {});
    } catch (e) {
      print('Erreur lors de l\'envoi de InslulinRemaining: $e');
    }
  }

  Future<void> sendLifeTime(BuildContext context) async {
    try {
      final appState = Provider.of<AppState>(context, listen: false);
      Duration lifeTime = appState.expireDate.difference(DateTime.now());
      int days = lifeTime.inDays;
      int hours = lifeTime.inHours
          .remainder(24); // Nombre d'heures restantes dans la journée
      String message = 'lifeTime: $days jours $hours heures';
      AppStateBluetooth.allBluetooth.sendMessage(message);

      // Ajout du message à la liste des messages
      messages.add(
        Message(
          message: message,
          isMe: true,
        ),
      );
    } catch (e) {
      print('Erreur lors de l\'envoi de lifeTime: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          ElevatedButton(
            onPressed: () {
              final appState = Provider.of<AppState>(context, listen: false);
              appState.isConnectedToPump = false;
              AppStateBluetooth.allBluetooth.closeConnection();
            },
            child: const Text("Fermer la connexion"),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ChatBubble(
                    clipper: ChatBubbleClipper4(
                      type: message.isMe
                          ? BubbleType.sendBubble
                          : BubbleType.receiverBubble,
                    ),
                    alignment:
                        message.isMe ? Alignment.topRight : Alignment.topLeft,
                    child: Text(message.message),
                  ),
                );
              },
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: messageController,
                  decoration: const InputDecoration(
                    enabledBorder: OutlineInputBorder(),
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  final message = messageController.text;
                  AppStateBluetooth.allBluetooth.sendMessage(message);
                  messageController.clear();
                  messages.add(
                    Message(
                      message: message,
                      isMe: true,
                    ),
                  );
                  setState(() {});
                },
                icon: const Icon(Icons.send),
              ),
              IconButton(
                onPressed: sendInsulinRemaining,
                icon: const Icon(Icons.arrow_circle_up),
                tooltip: 'Envoyer insulinRemaining',
              ),
              IconButton(
                onPressed: () {
                  sendLifeTime(context); // Utilisation d'une fonction anonyme
                },
                icon: const Icon(Icons.calendar_today),
                tooltip: 'Envoyer LifeTime',
              )
            ],
          )
        ],
      ),
    );
  }
}

class Message {
  final String message;
  final bool isMe;

  Message({required this.message, required this.isMe});
}
