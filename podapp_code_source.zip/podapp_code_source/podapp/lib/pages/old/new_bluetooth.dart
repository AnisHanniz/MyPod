import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class BluetoothServerWidget extends StatefulWidget {
  const BluetoothServerWidget({Key? key}) : super(key: key);

  @override
  _BluetoothServerWidgetState createState() =>
      _BluetoothServerWidgetState(); // Corrected the class name
}

// Corrected the class name to match the createState method
class _BluetoothServerWidgetState extends State<BluetoothServerWidget> {
  static const platform = MethodChannel('com.example.podapp/bluetooth_service');

  bool isListening = false;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
    ].request();
  }

  Future<void> _startBluetoothServer() async {
    try {
      final bool result = await platform.invokeMethod('startBluetoothService');
      setState(() {
        isListening = result;
      });
    } on PlatformException catch (e) {
      print("Failed to start Bluetooth service: '${e.message}'.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bluetooth Connect"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _startBluetoothServer,
        backgroundColor:
            isListening ? Colors.red : Theme.of(context).primaryColor,
        child: Icon(isListening ? Icons.stop : Icons.wifi_tethering),
      ),
      body: Center(
        child: isListening
            ? const Text("Bluetooth service is running.")
            : const Text("Press the button to start the Bluetooth service."),
      ),
    );
  }
}
