import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class BluetoothClientWidget extends StatefulWidget {
  const BluetoothClientWidget({Key? key}) : super(key: key);

  @override
  _BluetoothClientWidgetState createState() => _BluetoothClientWidgetState();
}

class _BluetoothClientWidgetState extends State<BluetoothClientWidget> {
  static const platform = MethodChannel('com.example.mypod/bluetooth');
  String connectionStatus = "Disconnected";

  @override
  void initState() {
    super.initState();
    _requestPermissions();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
    ].request();
  }

  Future<void> _connectToHost() async {
    try {
      const String deviceAddress =
          "DEVICE_ADDRESS_HERE"; // TODO: Replace with actual device address
      final String result = await platform
          .invokeMethod('connectToHost', {'deviceAddress': deviceAddress});
      setState(() {
        connectionStatus = "Connected to $result";
      });
    } on PlatformException catch (e) {
      setState(() {
        connectionStatus = "Failed to connect: '${e.message}'";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bluetooth Connect"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _connectToHost,
        backgroundColor: connectionStatus.startsWith("Connected")
            ? Colors.green
            : Theme.of(context).primaryColor,
        child: Icon(connectionStatus.startsWith("Connected")
            ? Icons.bluetooth_connected
            : Icons.bluetooth),
      ),
      body: Center(
        child: Text(connectionStatus),
      ),
    );
  }
}
