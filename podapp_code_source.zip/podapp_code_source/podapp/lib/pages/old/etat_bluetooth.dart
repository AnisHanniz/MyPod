import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:podapp/pages/accueil_page.dart';

class EtatBluetooth extends StatefulWidget {
  const EtatBluetooth({Key? key}) : super(key: key);

  @override
  State<EtatBluetooth> createState() => _EtatBluetoothState();
}

bool isConnected = false;

class _EtatBluetoothState extends State<EtatBluetooth> {
  bool isActivated = false;
  String errorMessage = "";

  FlutterBluePlus flutterBlue = FlutterBluePlus();
  List<BluetoothDevice> devices = [];

  void scannerBluetooth() async {
    await FlutterBluePlus.startScan();

    FlutterBluePlus.scanResults.listen((results) {
      for (ScanResult result in results) {
        if (!devices.contains(result.device) &&
            (Platform.isAndroid || Platform.isIOS) &&
            result.device.platformName != "") {
          setState(() {
            devices.add(result.device);
          });
        }
      }
    });
  }

  List<int> convertListToBytes(List<dynamic> dataList) {
    String jsonString = json.encode(dataList);
    List<int> byteList = utf8.encode(jsonString);
    return byteList;
  }

// Envoyer une liste de données
//   void handleData() async {
//     BluetoothCharacteristic characteristic;
//     List<int> convertListToBytes(List<dynamic> dataList) {
//       String jsonString = json.encode(dataList);
//       List<int> byteList = utf8.encode(jsonString);
//       return byteList;
//     }

  List<dynamic> convertBytesToList(List<int> byteList) {
    String jsonString = utf8.decode(byteList);
    List<dynamic> dataList = json.decode(jsonString);
    return dataList;
  }

  void isBluetoothActivated() {
    // BluetoothManager mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    // if (true) {
    //   String errorMessage = "Votre appareil ne supporte pas Bluetooth";
    // } else if (false) {
    //   isActivated = false;
    // } else {
    //   isActivated = true;
    // }
  }
  Future<void> handleData(BluetoothCharacteristic characteristic) async {
    // Recevoir des données
    List<int> receivedBytes = await characteristic.read();
    List<dynamic> receivedList = convertBytesToList(receivedBytes);
    print("Données reçues : $receivedList");

    // Envoyer des données
    List<dynamic> dataList = [1, 2, 3, 4, 5];
    List<int> bytesToSend = convertListToBytes(dataList);
    await characteristic.write(bytesToSend);
    print("Données envoyées : $dataList");
  }

  Future<void> connectToDevice(BluetoothDevice device) async {
    try {
      await device.connect();
      isConnected = true;
//Ajout de la fonction handleData
      // Obtenir les services du périphérique
      List<BluetoothService> services = await device.discoverServices();

      // Trouver la caractéristique que vous souhaitez utiliser pour envoyer et recevoir des données
      for (BluetoothService service in services) {
        List<BluetoothCharacteristic> characteristics = service.characteristics;
        for (BluetoothCharacteristic characteristic in characteristics) {
          // Identifier la caractéristique souhaitée par son UUID ou ses propriétés
          // Par exemple, si la caractéristique prend en charge la lecture et l'écriture :
          if (characteristic.properties.read &&
              characteristic.properties.write) {
            // Utilisez cette caractéristique pour lire et écrire des données
            await handleData(characteristic);
            return;
          }
        }
      }

      // La connexion a réussi
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text("Connexion réussie"),
            content: Text("Vous êtes connecté à ${device.platformName}"),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  AccueilPage();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      // La connexion a échoué
      isConnected = false;
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Échec de la connexion"),
            content: Text("La connexion à ${device.platformName} a échoué."),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 16),
        Expanded(
          child: isConnected
              ? Column(children: [
                  const Text("Vous êtes connecté à un appareil"),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AccueilPage()),
                      );
                    },
                    child: const Icon(Icons.home),
                  ),
                ])
              : devices.isEmpty
                  ? const Center(
                      child: Text(
                        "En attente de demande de connexion",
                        style: TextStyle(fontSize: 20),
                      ),
                    )
                  : ListView.builder(
                      itemCount: devices.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          onTap: () {
                            isBluetoothActivated();
                            connectToDevice(devices[index]);
                          },
                          title: Text(devices[index].platformName == ""
                              ? "Appareil sans nom"
                              : devices[index].platformName.toString()),
                          subtitle: Text(devices[index].remoteId.toString()),
                        );
                      },
                    ),
        ),
        FloatingActionButton(
          onPressed: scannerBluetooth,
          child: const Icon(Icons.bluetooth_searching_rounded),
        ),
        const SizedBox(height: 16)
      ],
    );
  }
}
