import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BluetoothManager {
  static const MethodChannel _channel =
      MethodChannel('com.example.podapp/bluetooth');

  Future<void> startServer() async {
    try {
      await _channel.invokeMethod('startServer');
      print("Server started successfully.");
    } on PlatformException catch (e) {
      print("Failed to start server: '${e.message}'.");
    }
  }

  Future<void> connectToHost(String deviceAddress) async {
    try {
      await _channel
          .invokeMethod('connectToHost', {"deviceAddress": deviceAddress});
      print("Connected to host successfully.");
    } on PlatformException catch (e) {
      print("Failed to connect to host: '${e.message}'.");
    }
  }

  Future<void> stopServer() async {
    try {
      await _channel.invokeMethod('stopServer');
      print("Server stopped successfully.");
    } on PlatformException catch (e) {
      print("Failed to stop server: '${e.message}'.");
    }
  }
}

class BluetoothServerWidget extends StatefulWidget {
  const BluetoothServerWidget({Key? key}) : super(key: key);

  @override
  _BluetoothServerWidgetState createState() => _BluetoothServerWidgetState();
}

class _BluetoothServerWidgetState extends State<BluetoothServerWidget> {
  final BluetoothManager bluetoothManager = BluetoothManager();
  String serverStatus = "Server is not running";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bluetooth Server'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(serverStatus),
            ElevatedButton(
              onPressed: () async {
                await bluetoothManager.startServer();
                setState(() {
                  serverStatus = "Server is running";
                });
              },
              child: const Text('Start Server'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                await bluetoothManager.stopServer();
                setState(() {
                  serverStatus = "Server has stopped";
                });
              },
              child: const Text('Stop Server'),
            ),
          ],
        ),
      ),
    );
  }
}
