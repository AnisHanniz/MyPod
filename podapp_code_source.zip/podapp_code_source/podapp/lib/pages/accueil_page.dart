import 'package:flutter/material.dart';
import 'package:podapp/pages/AppState.dart';
import 'package:podapp/pages/app_constants.dart';
import 'package:provider/provider.dart';

class AccueilPage extends StatefulWidget {
  const AccueilPage({Key? key}) : super(key: key);

  @override
  State<AccueilPage> createState() => _AccueilPageState();
}

class _AccueilPageState extends State<AccueilPage> {
  late double insulinRemaining;
  late double basalEnCours;
  late DateTime debutDate;
  late DateTime expireDate;
  late AppState appState;
  late double dernierBolus;

  double defaultInsulinRemaining = 120;

  double defaultBasalEnCours = 0.1;

  String calculateRemainingTime() {
    DateTime now = DateTime.now();
    Duration remainingDuration = expireDate.difference(now);
    int remainingDays = remainingDuration.inDays;
    int remainingHours = remainingDuration.inHours % 24;
    return "$remainingDays jours et $remainingHours heures";
  }

  @override
  Widget build(BuildContext context) {
    appState = Provider.of<AppState>(context, listen: false);
    insulinRemaining = appState.insulinRemaining;
    basalEnCours = appState.basalEnCours;
    debutDate = appState.debutDate;
    expireDate = appState.expireDate;
    dernierBolus = appState.dernierBolus;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 5),
      child: Column(
        children: [
          const SizedBox(
            height: 15,
          ),
          Container(
            decoration: BoxDecoration(
                color: Colors.purple.withOpacity(0.4),
                borderRadius: BorderRadius.circular(8.0)),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Etat Connexion :",
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
                Switch(
                  value: AppStateBluetooth
                      .isConnectedToPump, // Utilisation du getter
                  onChanged:
                      null, // Remplacer null par la fonction de gestion de changement si nécessaire
                  activeColor: AppStateBluetooth.isConnectedToPump
                      ? AppConstants.violet
                      : Colors.red.withOpacity(0.4),
                )
              ],
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          const Divider(
            color: Colors.white,
          ),
          Container(
            padding: const EdgeInsets.all(8.0),
            alignment: Alignment.center,
            width: 300,
            height: 250,
            decoration: BoxDecoration(
              color: Colors.purple.withOpacity(0.2),
              border: Border.all(
                color: Colors.purple.withOpacity(0.5),
                width: 5,
              ),
              borderRadius: BorderRadius.circular(80),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.opacity, color: Colors.white),
                    SizedBox(width: 15),
                    Text("Insuline restante", style: TextStyle(fontSize: 20)),
                  ],
                ),
                Text("${insulinRemaining.toStringAsFixed(2)} U"),
                const SizedBox(
                  height: 10,
                ),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.timeline, color: Colors.white),
                    SizedBox(width: 15),
                    Text("Basal En Cours", style: TextStyle(fontSize: 15)),
                  ],
                ),
                Text("${basalEnCours.toStringAsFixed(2)} U"),
                const SizedBox(
                  height: 10,
                ),
                LinearProgressIndicator(
                  value: insulinRemaining / 200,
                  valueColor:
                      const AlwaysStoppedAnimation<Color>(Colors.greenAccent),
                  backgroundColor: Colors.white,
                  minHeight: 15,
                ),
                const SizedBox(
                  height: 5,
                ),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("0 U",
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Text("25%",
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Text("50%",
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Text("75%",
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Text("200 U",
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          FloatingActionButton(
            onPressed: () {
              setState(() {
                debutDate = DateTime.now();
                insulinRemaining = defaultInsulinRemaining;
                basalEnCours = defaultBasalEnCours;
                expireDate = debutDate.add(const Duration(days: 3));
              });
            },
            backgroundColor: Colors.purple.withOpacity(0.4),
            child: const Icon(
              Icons.refresh_outlined,
              size: 25,
              color: Colors.white,
            ),
          ),
          const SizedBox(
            height: 40,
            width: 20,
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Card(
                  margin: const EdgeInsets.all(8.0),
                  color: Colors.purple,
                  elevation: 8.0,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Expiration POD",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Début : ${debutDate.toLocal()}",
                          style: const TextStyle(
                              fontSize: 16, color: Colors.white),
                        ),
                        Text(
                          "Expire : ${expireDate.toLocal()}",
                          style: const TextStyle(
                              fontSize: 16, color: Colors.white),
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          "Temps restant :",
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          calculateRemainingTime(),
                          style: const TextStyle(
                              fontSize: 16, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
                Card(
                  margin: const EdgeInsets.all(8.0),
                  color: Colors.purple,
                  elevation: 8.0,
                  child: SizedBox(
                    height: 150,
                    width: 200,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Text(
                            "Info Insuline",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Dernier Bolus : ${dernierBolus.toStringAsFixed(2)} U",
                            style: const TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
          const SizedBox(
            height: 40,
            width: 20,
          ),
          Card(
            margin: const EdgeInsets.all(8.0),
            color: Colors.purple,
            elevation: 8.0,
            child: SizedBox(
              height: 200,
              width: MediaQuery.sizeOf(context).width,
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(
                    "Profil Basal",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.normal,
                        color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
